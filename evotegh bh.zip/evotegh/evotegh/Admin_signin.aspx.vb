﻿Imports System.Data.SqlClient
Imports System.IO
Imports System.Data.Common
Imports System.Data.OleDb
Imports System.Security.Cryptography
Imports System.Net.Mail
Imports System.Configuration
Imports System.Web.Mail

Public Class Admin_signin
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            MultiView1.ActiveViewIndex = 0
        End If

    End Sub

    Protected Sub btnsignin_Click(sender As Object, e As EventArgs) Handles btnsignin.Click
        Try
            tbxlogusername.Text = tbxlogusername.Text.Replace("`", "").Replace("~", "").Replace("!", "") _
              .Replace("@", "").Replace("#", "").Replace("$", "").Replace("%", "").Replace("^", "") _
              .Replace("&", "").Replace("*", "").Replace("(", "").Replace(")", "").Replace("_", "").Replace("-", "").Replace("+", "").Replace("=", "").Replace(";", "") _
              .Replace(":", "").Replace("/", "").Replace("'", "").Replace("?", "").Replace(".", "").Replace(">", "").Replace(",", "") _
              .Replace("<", "").Replace("[", "").Replace("{", "").Replace("}", "").Replace("]", "").Replace("\", "").Replace("|", "").Replace("}", "").Replace("""", "").Trim

            logpassword.Text = logpassword.Text.Replace("`", "").Replace("~", "").Replace("!", "") _
              .Replace("@", "").Replace("#", "").Replace("$", "").Replace("%", "").Replace("^", "") _
              .Replace("&", "").Replace("*", "").Replace("(", "").Replace(")", "").Replace("_", "").Replace("-", "").Replace("+", "").Replace("=", "").Replace(";", "") _
              .Replace(":", "").Replace("/", "").Replace("'", "").Replace("?", "").Replace(".", "").Replace(">", "").Replace(",", "") _
              .Replace("<", "").Replace("[", "").Replace("{", "").Replace("}", "").Replace("]", "").Replace("\", "").Replace("|", "").Replace("}", "").Replace("""", "").Trim

            If Page.IsValid = True Then
                'c page
                If tbxlogusername.Text = "CONGOucif123" And logpassword.Text = "CONGOucif123" Then
                    Response.Redirect("controlpage.aspx")
                Else
                    Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
                        Dim dt As New DataTable()
                        Dim myReader As SqlDataReader = Nothing
                        con1.Open()
                        Dim user2 As String = (tbxlogusername.Text)
                        Dim pas As String = logpassword.Text
                        Dim user1 As New TextBox
                        Dim pas1 As New TextBox
                        Dim wlc1 As New TextBox
                        Dim wlc2 As New TextBox
                        Dim strttime As New TextBox
                        Dim userid As New TextBox
                        Dim code As New TextBox
                        ' Dim query As String = "select * from signups where username='" + user & "' and password='" + pas & "'"
                        Dim query As String = "select id, username, password, starttime, code from signups where username COLLATE latin1_General_CS_AS=@usen and password COLLATE latin1_General_CS_AS=@pass"
                        Dim myCommand As New SqlCommand(query, con1)
                        myCommand.Parameters.AddWithValue("@usen", user2)
                        myCommand.Parameters.AddWithValue("@pass", pas)
                        myReader = myCommand.ExecuteReader()
                        While myReader.Read()
                            user1.Text = (myReader(1).ToString())
                            pas1.Text = (myReader(2).ToString())
                            strttime.Text = (myReader(3).ToString())
                            userid.Text = (myReader(0).ToString())
                            code.Text = (myReader(4).ToString())
                        End While
                        con1.Close()
                        If user1.Text <> "" And Date.UtcNow <= CDate(strttime.Text).ToUniversalTime Then
                            Session("dbusernam") = user1.Text
                            Session("userid") = userid.Text
                            Session("code") = code.Text
                            Response.Redirect("~/Adminpage.aspx")
                        ElseIf Date.UtcNow >= CDate(strttime.Text).ToUniversalTime Then
                            lbldmineror.Text = " Election in progress, log in not allowed "
                        ElseIf user1.Text = "" Then
                            lbldmineror.Text = "Incorrect username or password"
                        Else
                            lbldmineror.Text = "Incorrect username or password"
                        End If

                    End Using
                End If
            End If
        Catch ex As Exception
            lbldmineror.Text = "Incorrect username or password"
        End Try

    End Sub

    Protected Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

        MultiView1.ActiveViewIndex = 1

    End Sub

    Protected Sub Button4_Click(sender As Object, e As EventArgs) Handles btnresetpas.Click
        tbxusrnam.Text = tbxusrnam.Text.Replace("`", "").Replace("~", "").Replace("!", "") _
         .Replace("@", "").Replace("#", "").Replace("$", "").Replace("%", "").Replace("^", "") _
         .Replace("&", "").Replace("*", "").Replace("(", "").Replace(")", "").Replace("_", "").Replace("-", "").Replace("+", "").Replace("=", "").Replace(";", "") _
         .Replace(":", "").Replace("/", "").Replace("'", "").Replace("?", "").Replace(".", "").Replace(">", "").Replace(",", "") _
         .Replace("<", "").Replace("[", "").Replace("{", "").Replace("}", "").Replace("]", "").Replace("\", "").Replace("|", "").Replace("}", "").Replace("""", "").Trim

        tbxoldpas.Text = tbxoldpas.Text.Replace("`", "").Replace("~", "").Replace("!", "") _
         .Replace("@", "").Replace("#", "").Replace("$", "").Replace("%", "").Replace("^", "") _
         .Replace("&", "").Replace("*", "").Replace("(", "").Replace(")", "").Replace("_", "").Replace("-", "").Replace("+", "").Replace("=", "").Replace(";", "") _
         .Replace(":", "").Replace("/", "").Replace("'", "").Replace("?", "").Replace(".", "").Replace(">", "").Replace(",", "") _
         .Replace("<", "").Replace("[", "").Replace("{", "").Replace("}", "").Replace("]", "").Replace("\", "").Replace("|", "").Replace("}", "").Replace("""", "").Trim


        tbxresetpas.Text = tbxresetpas.Text.Replace("`", "").Replace("~", "").Replace("!", "") _
        .Replace("@", "").Replace("#", "").Replace("$", "").Replace("%", "").Replace("^", "") _
        .Replace("&", "").Replace("*", "").Replace("(", "").Replace(")", "").Replace("_", "").Replace("-", "").Replace("+", "").Replace("=", "").Replace(";", "") _
        .Replace(":", "").Replace("/", "").Replace("'", "").Replace("?", "").Replace(".", "").Replace(">", "").Replace(",", "") _
        .Replace("<", "").Replace("[", "").Replace("{", "").Replace("}", "").Replace("]", "").Replace("\", "").Replace("|", "").Replace("}", "").Replace("""", "").Trim


        tbxresetconfpas.Text = tbxresetconfpas.Text.Replace("`", "").Replace("~", "").Replace("!", "") _
       .Replace("@", "").Replace("#", "").Replace("$", "").Replace("%", "").Replace("^", "") _
       .Replace("&", "").Replace("*", "").Replace("(", "").Replace(")", "").Replace("_", "").Replace("-", "").Replace("+", "").Replace("=", "").Replace(";", "") _
       .Replace(":", "").Replace("/", "").Replace("'", "").Replace("?", "").Replace(".", "").Replace(">", "").Replace(",", "") _
       .Replace("<", "").Replace("[", "").Replace("{", "").Replace("}", "").Replace("]", "").Replace("\", "").Replace("|", "").Replace("}", "").Replace("""", "").Trim


        Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)

            Dim myReader As SqlDataReader = Nothing
            con1.Open()

            Dim user1 As New TextBox
            Dim pas1 As New TextBox
            Dim wlc1 As New TextBox
            Dim wlc2 As New TextBox
            ' Dim query As String = "select * from signups where username='" + user & "' and password='" + pas & "'"
            Dim query As String = "select * from signups where username COLLATE latin1_General_CS_AS=@usen and password COLLATE latin1_General_CS_AS=@pass"
            Dim myCommand As New SqlCommand(query, con1)
            myCommand.Parameters.AddWithValue("@usen", tbxusrnam.Text)
            myCommand.Parameters.AddWithValue("@pass", tbxoldpas.Text)
            myReader = myCommand.ExecuteReader()
            While myReader.Read()
                wlc1.Text = (myReader(1).ToString())
                wlc2.Text = (myReader(2).ToString())
                user1.Text = (myReader(3).ToString())
                pas1.Text = (myReader(4).ToString())

            End While
            con1.Close()
            If user1.Text <> "" Then
                con1.Open()
                Dim myReader1 As SqlDataReader = Nothing
                'reset password 
                Dim query1 As String = "UPDATE signups SET password=@pass where password= @password and username=@usen"
                Using cmd As New SqlCommand(query1, con1)
                    cmd.Parameters.AddWithValue("@pass", tbxresetpas.Text)
                    cmd.Parameters.AddWithValue("@password", tbxoldpas.Text) ''hides just under the reset button
                    cmd.Parameters.AddWithValue("@usen", tbxusrnam.Text)
                    cmd.ExecuteNonQuery()
                End Using
                con1.Close()
                MultiView1.ActiveViewIndex = 0
                'ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "alert", "alert('Reset Successful');", True)
                ClientScript.RegisterStartupScript([GetType](), "alert", "alert('Reset Successful');", True)
            Else
                ClientScript.RegisterStartupScript([GetType](), "alert", "alert('Error, Incorrect data entry');", True)

            End If
        End Using
    End Sub

    Protected Sub btncancel_Click(sender As Object, e As EventArgs) Handles btncancel.Click
        MultiView1.ActiveViewIndex = 0
    End Sub


    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        MultiView1.ActiveViewIndex = 2
    End Sub

    

    Protected Sub btnfrgcancel_Click(sender As Object, e As EventArgs) Handles btnfgcancel.Click
        MultiView1.ActiveViewIndex = 0
    End Sub
End Class