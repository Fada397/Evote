﻿Imports System.Data.SqlClient
Imports System.Drawing
Imports System.IO
Imports System.Data.OleDb
Imports System.Data.Common
Imports System.Runtime.InteropServices
Imports System.Drawing.Design
Imports System.Configuration

Public Class Adminpage
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            tbxusername.Text = Session("dbusernam")
            tbxuserid.Text = Session("userid")

            If tbxuserid.Text = "" Then 'if cookies disabled
                Response.Redirect("~/cookiesdisabled.aspx")
            End If

            btnview_Click(btnview, Nothing)
            lbladminwelc.Text = "Logged in: " & tbxusername.Text & " Code: " & Session("code")
        End If
    End Sub



    Private Sub Loadpositionsaddcand()
        Try
            Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
                con1.Open()
                'find positions from position table
                Dim myReader1 As SqlDataReader = Nothing
                Dim query1 As String = "select id, position from tblpos where userid = @id"
                Dim myCommand1 As New SqlCommand(query1, con1)
                myCommand1.Parameters.AddWithValue("@id", tbxuserid.Text)
                lbxpos_addcand.DataSource = myCommand1.ExecuteReader()
                lbxpos_addcand.DataTextField = "position"
                lbxpos_addcand.DataValueField = "id"
                lbxpos_addcand.DataBind()
                con1.Close()
            End Using
        Catch ex As Exception

        End Try
    End Sub


    Private Sub Loadpositionseditpos()
        Try

            Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)

                con1.Open()
                'find positions from position table
                Dim myReader1 As SqlDataReader = Nothing
                Dim query1 As String = "select id, position from tblpos where userid = @id"
                Dim myCommand1 As New SqlCommand(query1, con1)
                myCommand1.Parameters.AddWithValue("@id", tbxuserid.Text)
                drpbxpos_editpos.DataSource = myCommand1.ExecuteReader()
                drpbxpos_editpos.DataTextField = "position"
                drpbxpos_editpos.DataValueField = "id"
                drpbxpos_editpos.DataBind()

                con1.Close()
            End Using
        Catch ex As Exception

        End Try
    End Sub


    Private Sub Loadpositionseditcand()
        Try

            Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)

                con1.Open()
                'find positions from position table
                Dim myReader1 As SqlDataReader = Nothing
                Dim query1 As String = "select id, position from tblpos where userid = @id"
                Dim myCommand1 As New SqlCommand(query1, con1)
                myCommand1.Parameters.AddWithValue("@id", tbxuserid.Text)
                dropbxeditcand.DataSource = myCommand1.ExecuteReader()
                dropbxeditcand.DataTextField = "position"
                dropbxeditcand.DataValueField = "id"
                dropbxeditcand.DataBind()
                con1.Close()
            End Using
        Catch ex As Exception

        End Try
    End Sub




    Private Sub Loadpositionsview()
        Try
            Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
                con1.Open()
                'find positions from position table
                Dim myReader1 As SqlDataReader = Nothing
                Dim query1 As String = "select id, position from tblpos where userid = @id"
                Dim myCommand1 As New SqlCommand(query1, con1)
                myCommand1.Parameters.AddWithValue("@id", tbxuserid.Text)
                myCommand1.Parameters.AddWithValue("@pos", lbxpos_addcand.Text.ToString())

                dbxvpos.DataSource = myCommand1.ExecuteReader()
                dbxvpos.DataTextField = "position"
                dbxvpos.DataValueField = "id"
                dbxvpos.DataBind()

                con1.Close()
            End Using

            ' loadcandidates()

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub Loadcandidates_view()
        Try
            Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
                Dim obj As SqlCommand
                obj = con1.CreateCommand

                Dim posid As Integer = CInt(dbxvpos.SelectedValue.ToString)

                Const query As String = "select id, name from tblcand where postid = @posid"
                Dim myCommand As New SqlCommand(query, con1)
                myCommand.Parameters.AddWithValue("@posid", posid)
                con1.Open()
                lbxvcand.DataSource = myCommand.ExecuteReader
                lbxvcand.DataTextField = "name"
                lbxvcand.DataValueField = "id"
                lbxvcand.DataBind()
                con1.Close()
            End Using
            ' Lblcand.Text = (lbxpos_addcand.SelectedItem.ToString).ToUpper
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub Loadcandidates_editcand()
        Try
            Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
                Dim obj As SqlCommand
                obj = con1.CreateCommand
                Dim posid As Integer = CInt(dropbxeditcand.SelectedValue.ToString)
                Const query As String = "select id, name from tblcand where postid = @posid"
                Dim myCommand As New SqlCommand(query, con1)
                myCommand.Parameters.AddWithValue("@posid", posid)
                con1.Open()
                lbxeditcand.DataSource = myCommand.ExecuteReader
                lbxeditcand.DataTextField = "name"
                lbxeditcand.DataValueField = "id"
                lbxeditcand.DataBind()
                con1.Close()
            End Using

            If lbxeditcand.Items.Count = 0 Then
                tbxediEmail.Text = ""
                tbxeditName.Text = ""
                tbxeditPhone.Text = ""

            End If
            ' Lblcand.Text = (lbxpos_addcand.SelectedItem.ToString).ToUpper
        Catch ex As Exception

        End Try
    End Sub


    Protected Sub loaddetailcand_view()
        'Try
        Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
            Dim obj As SqlCommand
            obj = con1.CreateCommand
            Dim img As New TextBox
            Dim myReader As SqlDataReader = Nothing
            Dim candid As Integer = lbxvcand.SelectedValue
            Const query As String = "select name, email, phone, image,refno  from tblcand where id = @id"
            Dim myCommand As New SqlCommand(query, con1)
            con1.Open()
            myCommand.Parameters.AddWithValue("@id", candid)
            myReader = myCommand.ExecuteReader()
            While myReader.Read()
                tbxvname.Text = (myReader(0).ToString())
                img.Text = (myReader(3).ToString())
                tbxvemail.Text = (myReader(1).ToString())
                tbxvphon.Text = (myReader(2).ToString())
                tbxvref.Text = (myReader(4).ToString())
            End While
            Imgview.ImageUrl = ("~/databasepics/" & img.Text)
            con1.Close()
        End Using
        ' Lblcand.Text = (lbxpos_addcand.SelectedItem.ToString).ToUpper
        'Catch ex As Exception
        'End Try
    End Sub

    Protected Sub loaddetailcand_editcand()
        'Try
        Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
            Dim obj As SqlCommand
            obj = con1.CreateCommand
            Dim img As New TextBox
            Dim myReader As SqlDataReader = Nothing
            Dim candid As Integer = CInt(lbxeditcand.SelectedValue.ToString)
            Const query As String = "select name, email, phone, image from tblcand where id = @id"
            Dim myCommand As New SqlCommand(query, con1)
            con1.Open()
            myCommand.Parameters.AddWithValue("@id", candid)
            myReader = myCommand.ExecuteReader()
            While myReader.Read()
                tbxeditName.Text = (myReader(0).ToString())
                img.Text = (myReader(3).ToString())
                tbxediEmail.Text = (myReader(1).ToString())
                tbxeditPhone.Text = (myReader(2).ToString())
            End While
            Image2.ImageUrl = ("~/databasepics/" & img.Text)
            con1.Close()
        End Using
        ' Lblcand.Text = (lbxpos_addcand.SelectedItem.ToString).ToUpper
        'Catch ex As Exception
        'End Try
    End Sub


    Protected Sub btnview_Click(sender As Object, e As EventArgs) Handles btnview.Click
        Try

            AddPositions.BorderStyle = BorderStyle.NotSet
            AddCandidates.BorderStyle = BorderStyle.NotSet
            Voters.BorderStyle = BorderStyle.NotSet
            Edit_Delete.BorderStyle = BorderStyle.NotSet
            btnview.BorderStyle = BorderStyle.None

            AddPositions.Style.Add("background-color", "silver")
            Voters.Style.Add("background-color", "Silver")
            AddCandidates.Style.Add("background-color", "Silver")
            Edit_Delete.Style.Add("background-color", "Silver")
            btnview.Style.Add("background-color", "#CCCCCC")



            MultiView1.ActiveViewIndex = 6
            dbxvpos.Items.Clear()
            Loadpositionsview()


            Loadcandidates_view()
            lbxvcand.SelectedIndex = 0
            lbxvcand_SelectedIndexChanged1(lbxvcand, Nothing)

        Catch ex As Exception

        End Try
    End Sub


    Protected Sub AddPositions_Click(sender As Object, e As EventArgs) Handles AddPositions.Click
        Try

            MultiView1.ActiveViewIndex = 0


            AddPositions.BorderStyle = BorderStyle.None
            AddCandidates.BorderStyle = BorderStyle.NotSet
            Voters.BorderStyle = BorderStyle.NotSet
            Edit_Delete.BorderStyle = BorderStyle.NotSet
            btnview.BorderStyle = BorderStyle.NotSet

            AddPositions.Style.Add("background-color", "#CCCCCC")
            Voters.Style.Add("background-color", "Silver")
            AddCandidates.Style.Add("background-color", "Silver")
            Edit_Delete.Style.Add("background-color", "Silver")
            btnview.Style.Add("background-color", "Silver")


        Catch ex As Exception

        End Try
    End Sub

    Protected Sub AddCandidates_Click(sender As Object, e As EventArgs) Handles AddCandidates.Click
        Try

            MultiView1.ActiveViewIndex = 1
            lbxpos_addcand.Items.Clear()
            Loadpositionsaddcand()
            lbxpos_addcand.Items.Insert(0, "----Select----")

            AddPositions.BorderStyle = BorderStyle.NotSet
            AddCandidates.BorderStyle = BorderStyle.None
            Voters.BorderStyle = BorderStyle.NotSet
            Edit_Delete.BorderStyle = BorderStyle.NotSet
            btnview.BorderStyle = BorderStyle.NotSet

            AddCandidates.Style.Add("background-color", "#CCCCCC")
            Voters.Style.Add("background-color", "Silver")
            AddPositions.Style.Add("background-color", "Silver")
            Edit_Delete.Style.Add("background-color", "Silver")
            btnview.Style.Add("background-color", "Silver")


        Catch ex As Exception

        End Try
    End Sub

    Protected Sub Voters_Click(sender As Object, e As EventArgs) Handles Voters.Click
        Try

            MultiView1.ActiveViewIndex = 2

            AddPositions.BorderStyle = BorderStyle.NotSet
            AddCandidates.BorderStyle = BorderStyle.NotSet
            Voters.BorderStyle = BorderStyle.None
            Edit_Delete.BorderStyle = BorderStyle.NotSet
            btnview.BorderStyle = BorderStyle.NotSet

            AddCandidates.Style.Add("background-color", "silver")
            Voters.Style.Add("background-color", "#CCCCCC")
            AddPositions.Style.Add("background-color", "Silver")
            Edit_Delete.Style.Add("background-color", "silver")
            btnview.Style.Add("background-color", "Silver")

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub Edit_Delete_Click(sender As Object, e As EventArgs) Handles Edit_Delete.Click
        Try
            MultiView1.ActiveViewIndex = 3
            'lbxpos_addcand.Items.Clear()
            'loadpositionsaddcand()
            rbneditpos.Checked = False
            rbneditcand.Checked = False
            rbneditvoters.Checked = False
            rbneditaccount.Checked = False


            AddPositions.BorderStyle = BorderStyle.NotSet
            AddCandidates.BorderStyle = BorderStyle.NotSet
            Voters.BorderStyle = BorderStyle.NotSet
            Edit_Delete.BorderStyle = BorderStyle.None
            btnview.BorderStyle = BorderStyle.NotSet

            AddCandidates.Style.Add("background-color", "silver")
            Voters.Style.Add("background-color", "Silver")
            AddPositions.Style.Add("background-color", "Silver")
            Edit_Delete.Style.Add("background-color", "#CCCCCC")
            btnview.Style.Add("background-color", "Silver")

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub btnposok_view2_Click(sender As Object, e As EventArgs) Handles btnposok_view2.Click
        Try


            tbxposname.Text = tbxposname.Text.Replace("`", "").Replace("~", "").Replace("!", "") _
     .Replace("@", "").Replace("#", "").Replace("$", "").Replace("%", "").Replace("^", "") _
     .Replace("&", "").Replace("*", "").Replace("(", "").Replace(")", "").Replace("_", "").Replace("-", "").Replace("+", "").Replace("=", "").Replace(";", "") _
     .Replace(":", "").Replace("/", "").Replace("'", "").Replace("?", "").Replace(".", "").Replace(">", "").Replace(",", "") _
     .Replace("<", "").Replace("[", "").Replace("{", "").Replace("}", "").Replace("]", "").Replace("\", "").Replace("|", "").Replace("}", "").Replace("""", "").Trim



            Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
                con1.Open()
                Dim sch As New TextBox
                Dim myreaderch As SqlDataReader = Nothing
                Dim querych As String = "select id from tblpos where userid = @userid and position=@pos"
                Dim myCommandch As New SqlCommand(querych, con1)
                myCommandch.Parameters.AddWithValue("@userid", tbxuserid.Text)
                myCommandch.Parameters.AddWithValue("@pos", tbxposname.Text)
                myreaderch = myCommandch.ExecuteReader()
                While myreaderch.Read()
                    sch.Text = (myreaderch(0).ToString())
                End While
                con1.Close()

                If sch.Text = "" Then
                    con1.Open()
                    Dim queryimg As String = "  insert into  tblpos  values (@pos, @userid) "
                    Dim cmdimg As New SqlCommand(queryimg, con1)
                    cmdimg.Parameters.AddWithValue("@pos", tbxposname.Text.ToUpper)
                    cmdimg.Parameters.AddWithValue("@userid", tbxuserid.Text)
                    cmdimg.ExecuteNonQuery()
                    con1.Close()

                    ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "alert", "alert('Save Successfully');", True)
                    tbxposname.Text = ""
                ElseIf sch.Text <> "" Then
                    ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "alert", "alert('ERROR, " + tbxposname.Text + "  already exist');", True)
                End If
                'add position to position table
            End Using

        Catch ex As Exception
            ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "alert", "alert('ERROR, Check data entry');", True)
            '    'ClientScript.RegisterStartupScript([GetType](), "alert", "alert('ERROR, " + tbxposname.Text + "  already exist' );", True)
        End Try
    End Sub


    Private Sub delete()
        Dim delpath As String = Server.MapPath(Session("imagepp"))
        System.IO.File.Delete(delpath)
    End Sub

    Protected Sub lbxpos_addcand_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lbxpos_addcand.SelectedIndexChanged
        Try
            Loadcandidatesadcand()

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub Loadcandidatesadcand()
        Try
            Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
                Dim obj As SqlCommand
                obj = con1.CreateCommand

                Dim posid As Integer = lbxpos_addcand.SelectedValue

                Const query As String = "select id, name from tblcand where postid = @posid"
                Dim myCommand As New SqlCommand(query, con1)
                myCommand.Parameters.AddWithValue("@posid", posid)
                con1.Open()
                lbxcandidate.DataSource = myCommand.ExecuteReader
                lbxcandidate.DataTextField = "name"
                lbxcandidate.DataValueField = "id"
                lbxcandidate.DataBind()
                con1.Close()
            End Using
            ' Lblcand.Text = (lbxpos_addcand.SelectedItem.ToString).ToUpper
        Catch ex As Exception

        End Try
    End Sub


    Protected Sub btnsaveposcandtes_Click(sender As Object, e As EventArgs) Handles btnsaveposcandtes.Click
        Try
            tbxcname.Text = tbxcname.Text.Replace("`", "").Replace("~", "").Replace("!", "") _
     .Replace("@", "").Replace("#", "").Replace("$", "").Replace("%", "").Replace("^", "") _
     .Replace("&", "").Replace("*", "").Replace("(", "").Replace(")", "").Replace("_", "").Replace("-", "").Replace("+", "").Replace("=", "").Replace(";", "") _
     .Replace(":", "").Replace("/", "").Replace("'", "").Replace("?", "").Replace(".", "").Replace(">", "").Replace(",", "") _
     .Replace("<", "").Replace("[", "").Replace("{", "").Replace("}", "").Replace("]", "").Replace("\", "").Replace("|", "").Replace("}", "").Replace("""", "").Trim

            cphone.Text = cphone.Text.Replace("`", "").Replace("~", "").Replace("!", "") _
     .Replace("@", "").Replace("#", "").Replace("$", "").Replace("%", "").Replace("^", "") _
     .Replace("&", "").Replace("*", "").Replace("(", "").Replace(")", "").Replace("_", "").Replace("-", "").Replace("+", "").Replace("=", "").Replace(";", "") _
     .Replace(":", "").Replace("/", "").Replace("'", "").Replace("?", "").Replace(".", "").Replace(">", "").Replace(",", "") _
     .Replace("<", "").Replace("[", "").Replace("{", "").Replace("}", "").Replace("]", "").Replace("\", "").Replace("|", "").Replace("}", "").Replace("""", "").Trim


            If lbxpos_addcand.SelectedIndex > 0 Then
                'save image
                Dim photoname As String = lbxpos_addcand.SelectedValue.ToString & cphone.Text
                If uploadphoto.HasFile Then            'or  FileUpload1.FileName.ToString <> "" Then
                    Dim filextension As String = System.IO.Path.GetExtension(uploadphoto.FileName)       'restrict to picturues only

                    If filextension.ToLower() = ".jpg" Or filextension.ToLower() = ".png" Or filextension.ToLower() = ".jpeg" Or filextension.ToLower() = ".gif" _
                     Or filextension.ToLower() = ".bmp" Or filextension.ToLower() = ".wmf" Or filextension.ToLower() = ".jpeg" Then

                        Dim filesize As Integer = uploadphoto.PostedFile.ContentLength     'set maximum filesize
                        If filesize > 2097152 Then        ' filesize in bytes..1MB=1024 *1024 bytes  
                            ClientScript.RegisterStartupScript([GetType](), "alert", "alert('maximum filesize(2MB) exceeded');", True)              'maximum filesize(2MB) exceeded"
                        Else


                            uploadphoto.SaveAs(Server.MapPath("~/databasepics/" & photoname & uploadphoto.FileName))
                            Dim photo As String = photoname & uploadphoto.FileName

                            Dim connectionString As String = (ConfigurationManager.ConnectionStrings("connection").ConnectionString)
                            Dim con As SqlConnection = New SqlConnection(connectionString)

                            con.Open()
                            Dim cmd As SqlCommand = New SqlCommand("addcand", con) 'Specify that the SqlCommand is a stored procedure
                            ' cmd.CommandType = System.Data.CommandType.StoredProcedure
                            cmd.Connection = con
                            cmd.CommandText = "addcand"
                            cmd.CommandType = CommandType.StoredProcedure
                            cmd.Parameters.AddWithValue("@userid", tbxuserid.Text)
                            cmd.Parameters.AddWithValue("@pos", lbxpos_addcand.SelectedItem.ToString())

                            cmd.Parameters.AddWithValue("@nam", tbxcname.Text)
                            cmd.Parameters.AddWithValue("@email", cemail.Text)
                            cmd.Parameters.AddWithValue("@phon", cphone.Text)
                            cmd.Parameters.AddWithValue("@img", photo)
                            cmd.Parameters.AddWithValue("@vot", 0)
                            cmd.Parameters.AddWithValue("@votup", 0)


                            cmd.Parameters.Add("@posid", SqlDbType.Int)
                            cmd.Parameters("@posid").Direction = ParameterDirection.Output

                            cmd.Parameters.Add("@exist", SqlDbType.Int)
                            cmd.Parameters("@exist").Direction = ParameterDirection.Output

                            Dim sqlReader As SqlDataReader = cmd.ExecuteReader()
                            sqlReader.Close()


                            lbxpos_addcand_SelectedIndexChanged(lbxpos_addcand, Nothing)

                            If IsDBNull((cmd.Parameters("@exist").Value)) Then
                                ClientScript.RegisterStartupScript([GetType](), "alert", "alert('Save Successfull');", True)
                                tbxcname.Text = ""
                                cphone.Text = ""
                                cemail.Text = ""
                            Else
                                ClientScript.RegisterStartupScript([GetType](), "alert", "alert('Candidate already exist');", True)
                            End If

                        End If
                    Else
                        ClientScript.RegisterStartupScript([GetType](), "alert", "alert('Upload picture only');", True) ' Upload picture only
                    End If
                ElseIf uploadphoto.HasFile = False Then
                    ClientScript.RegisterStartupScript([GetType](), "alert", "alert('Please Upload Candidate Picture');", True)
                End If
            ElseIf lbxpos_addcand.SelectedIndex <= 0 Then
                ClientScript.RegisterStartupScript([GetType](), "alert", "alert('Error, please select position');", True)
            End If
        Catch ex As Exception
            ClientScript.RegisterStartupScript([GetType](), "alert", "alert('ERROR, Check Data Entry');", True)
        End Try
    End Sub


    Protected Sub rbneditpos_CheckedChanged(sender As Object, e As EventArgs) Handles rbneditpos.CheckedChanged
        Try
            MultiView1.ActiveViewIndex = 4
            drpbxpos_editpos.Items.Clear()
            'loadpositions_editpos()
            Loadpositionseditpos()
            drpbxpos_editpos.Items.Insert(0, "----Select---")
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub rbneditvoters_CheckedChanged(sender As Object, e As EventArgs) Handles rbneditvoters.CheckedChanged
        Try
            MultiView1.ActiveViewIndex = 2
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub rbneditcand_CheckedChanged(sender As Object, e As EventArgs) Handles rbneditcand.CheckedChanged
        Try
            MultiView1.ActiveViewIndex = 5
            dropbxeditcand.Items.Clear()
            Loadpositionseditcand()

            dropbxeditcand.Items.Insert(0, "---Select---")


            'loadcandidate_editcand()
            'lbxeditcand.SelectedIndex = 0
            'lbxeditcand_SelectedIndexChanged(lbxeditcand, Nothing)

        Catch ex As Exception

        End Try

    End Sub


    Protected Sub dropbxeditcand_SelectedIndexChanged(sender As Object, e As EventArgs) Handles dropbxeditcand.SelectedIndexChanged
        Try
            Loadcandidates_editcand()

            lbxeditcand.SelectedIndex = 0
            lbxeditcand_SelectedIndexChanged(lbxeditcand, Nothing)
        Catch ex As Exception

        End Try
    End Sub





    Protected Sub lbxeditcand_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lbxeditcand.SelectedIndexChanged
        Try
            loaddetailcand_editcand()

        Catch ex As Exception

        End Try
    End Sub



    Protected Sub update_Click(sender As Object, e As EventArgs) Handles update.Click
        Try
            tbxeditName.Text = tbxeditName.Text.Replace("`", "").Replace("~", "").Replace("!", "") _
     .Replace("@", "").Replace("#", "").Replace("$", "").Replace("%", "").Replace("^", "") _
     .Replace("&", "").Replace("*", "").Replace("(", "").Replace(")", "").Replace("_", "").Replace("-", "").Replace("+", "").Replace("=", "").Replace(";", "") _
     .Replace(":", "").Replace("/", "").Replace("'", "").Replace("?", "").Replace(".", "").Replace(">", "").Replace(",", "") _
     .Replace("<", "").Replace("[", "").Replace("{", "").Replace("}", "").Replace("]", "").Replace("\", "").Replace("|", "").Replace("}", "").Replace("""", "").Trim

            tbxeditPhone.Text = tbxeditPhone.Text.Replace("`", "").Replace("~", "").Replace("!", "") _
     .Replace("@", "").Replace("#", "").Replace("$", "").Replace("%", "").Replace("^", "") _
     .Replace("&", "").Replace("*", "").Replace("(", "").Replace(")", "").Replace("_", "").Replace("-", "").Replace("+", "").Replace("=", "").Replace(";", "") _
     .Replace(":", "").Replace("/", "").Replace("'", "").Replace("?", "").Replace(".", "").Replace(">", "").Replace(",", "") _
     .Replace("<", "").Replace("[", "").Replace("{", "").Replace("}", "").Replace("]", "").Replace("\", "").Replace("|", "").Replace("}", "").Replace("""", "").Trim




            Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
                Dim dt As New DataTable()
                con1.Open()

                Dim query As String = "UPDATE tblcand  SET name = @name , email = @email , phone = @phone   where id = @id"
                Using cmd As New SqlCommand(query, con1)
                    cmd.Parameters.AddWithValue("@name", tbxeditName.Text)
                    cmd.Parameters.AddWithValue("@email", tbxediEmail.Text)
                    cmd.Parameters.AddWithValue("@phone", tbxeditPhone.Text)
                    cmd.Parameters.AddWithValue("@id", lbxeditcand.SelectedValue)
                    cmd.ExecuteNonQuery()
                End Using
            End Using
            dropbxeditcand_SelectedIndexChanged(dropbxeditcand, Nothing)

            ClientScript.RegisterStartupScript([GetType](), "alert", "alert('Save Successful');", True)
        Catch ex As Exception
            ClientScript.RegisterStartupScript([GetType](), "alert", "alert('ERROR, Check Data Entry');", True)
        End Try

    End Sub


    Protected Sub dltcandidate(sender As Object, e As EventArgs) Handles btndltcandidate.Click
        Try
            Dim confirmValue As String = Request.Form("confirm_value")
            If confirmValue = "Yes" Then
                Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
                    Dim dt As New DataTable()
                    con1.Open()
                    Dim query As String = "Delete from tblcand   where id = @id"
                    Using cmd As New SqlCommand(query, con1)
                        cmd.Parameters.AddWithValue("@id", lbxeditcand.SelectedValue)
                        cmd.ExecuteNonQuery()
                    End Using
                    con1.Close()
                    dropbxeditcand_SelectedIndexChanged(dropbxeditcand, Nothing)
                End Using
            Else
            End If

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub Confirmdelete(ByVal sender As Object, ByVal e As EventArgs) Handles btndeletepos.Click
        Try
            Dim confirmValue As String = Request.Form("confirm_value")
            If confirmValue = "Yes" Then
                Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
                    con1.Open()

                    Dim posid As Integer = CInt(drpbxpos_editpos.SelectedValue.ToString)
                    Dim query1 As String = "DELETE from tblpos where id=@posid"
                    Using cmd As New SqlCommand(query1, con1)
                        cmd.Parameters.AddWithValue("@posid", posid)
                        cmd.ExecuteNonQuery()
                    End Using
                    con1.Close()
                End Using
                'ClientScript.RegisterStartupScript([GetType](), "alert", "alert('Save Successful');", True)
                Loadpositionseditpos()
                drpbxpos_editpos.Items.Insert(0, "----Select---")
                tbxeditpos.Text = ""
            Else
            End If
        Catch ex As Exception
        End Try
    End Sub

    Protected Sub drpbxpos_editpos_SelectedIndexChanged(sender As Object, e As EventArgs) Handles drpbxpos_editpos.SelectedIndexChanged
        Try
            If drpbxpos_editpos.SelectedIndex > 0 Then
                tbxeditpos.Text = drpbxpos_editpos.SelectedItem.ToString
            Else
                tbxeditpos.Text = ""
            End If

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Try

            tbxeditpos.Text = tbxeditpos.Text.Replace("`", "").Replace("~", "").Replace("!", "") _
     .Replace("@", "").Replace("#", "").Replace("$", "").Replace("%", "").Replace("^", "") _
     .Replace("&", "").Replace("*", "").Replace("(", "").Replace(")", "").Replace("_", "").Replace("-", "").Replace("+", "").Replace("=", "").Replace(";", "") _
     .Replace(":", "").Replace("/", "").Replace("'", "").Replace("?", "").Replace(".", "").Replace(">", "").Replace(",", "") _
     .Replace("<", "").Replace("[", "").Replace("{", "").Replace("}", "").Replace("]", "").Replace("\", "").Replace("|", "").Replace("}", "").Replace("""", "").Trim
            Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
                con1.Open()
                Dim posid As Integer = CInt(drpbxpos_editpos.SelectedValue.ToString)
                Dim query1 As String = "UPDATE tblpos  SET position = @pos where id=@posid"
                Using cmd As New SqlCommand(query1, con1)
                    cmd.Parameters.AddWithValue("@pos", tbxeditpos.Text.ToUpper)
                    cmd.Parameters.AddWithValue("@posid", posid)
                    cmd.ExecuteNonQuery()
                End Using

                con1.Close()
            End Using
            tbxeditpos.Text = ""
            ClientScript.RegisterStartupScript([GetType](), "alert", "alert('Save Successful');", True)
            Loadpositionseditpos()
            drpbxpos_editpos.Items.Insert(0, "----Select---")

            'drpbxpos_editpos.Items.Clear()
            'loadpositions_editpos()

        Catch ex As Exception
            ClientScript.RegisterStartupScript([GetType](), "alert", "alert('Error, please check data entry');", True)
        End Try
    End Sub


    Protected Sub dbxvpos_SelectedIndexChanged(sender As Object, e As EventArgs) Handles dbxvpos.SelectedIndexChanged
        Try
            Loadcandidates_view()

            Dim candcount As Integer = CInt(lbxvcand.Items.Count)
            'clear fields if empty
            If candcount = 0 Then
                tbxvname.Text = ""
                tbxvphon.Text = ""
                _tbxvemail.Text = ""
                Imgview.ImageUrl = ""
            End If

            lbxvcand.SelectedIndex = 0
            lbxvcand_SelectedIndexChanged1(lbxvcand, Nothing)

        Catch ex As Exception

        End Try
    End Sub



    Protected Sub lbxvcand_SelectedIndexChanged1(sender As Object, e As EventArgs) Handles lbxvcand.SelectedIndexChanged
        Try
            loaddetailcand_view()

            If lbxvcand.SelectedIndex = lbxvcand.Items.Count - 1 Then
                btnviewnext.Enabled = False
                btnviewprev.Enabled = True
            ElseIf lbxvcand.SelectedIndex = 0 Then
                btnviewprev.Enabled = False
                btnviewnext.Enabled = True
            End If
        Catch ex As Exception
        End Try
    End Sub



    Protected Sub btnsavevot_Click(sender As Object, e As EventArgs) Handles btnsavevot.Click
        'Try
        Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
            'check if password sms is not sent
            Dim sms As New TextBox
            Dim myReaderma As SqlDataReader = Nothing
            con1.Open()
            Dim queryma As String = "select  smssent from signups where id=@userid"
            Dim myCommandma As New SqlCommand(queryma, con1)
            myCommandma.Parameters.AddWithValue("@userid", tbxuserid.Text)
            
            myReaderma = myCommandma.ExecuteReader()
            While myReaderma.Read()
                sms.Text = (myReaderma(0).ToString())
            End While
            myReaderma.Close()
            con1.Close()
            If sms.Text = "NO" Then
                'check if data already exist
                Dim lbxloadvters As New ListBox
                con1.Open()
                Dim queryv As String = "select  name from  tblvoters where userid=@userid"
                Dim myCommandv As New SqlCommand(queryv, con1)
                myCommandv.Parameters.AddWithValue("@userid", tbxuserid.Text)
                lbxloadvters.DataSource = myCommandv.ExecuteReader()
                lbxloadvters.DataTextField = "name"
                lbxloadvters.DataValueField = "name"
                lbxloadvters.DataBind()
                con1.Close()
                Dim filextension As String = System.IO.Path.GetExtension(voterupload.FileName)       'restrict to csv only
                Dim path As String = String.Concat((Server.MapPath("~/csv/" + voterupload.FileName)))
                voterupload.PostedFile.SaveAs(path)
                If filextension.ToLower() = ".csv" Then
                        If lbxloadvters.Items.Count < 1 Then 'does not contain voters for the acccount
                            If voterupload.HasFile Then
                                Dim dt As New DataTable()
                                Dim line As String = Nothing
                                Dim i As Integer = 0
                                Using sr As StreamReader = File.OpenText(Path)
                                    line = sr.ReadLine()
                                    Do While line IsNot Nothing
                                        Dim data() As String = line.Split(","c)
                                        If data.Length > 0 Then
                                            If i = 0 Then
                                                For Each item In data
                                                    dt.Columns.Add(New DataColumn())
                                                Next item
                                                i += 1
                                            End If
                                            Dim row As DataRow = dt.NewRow()
                                            row.ItemArray = data
                                            dt.Rows.Add(row)
                                        End If
                                        line = sr.ReadLine()
                                    Loop
                                End Using

                            con1.Open()
                            Dim cmd As SqlCommand = con1.CreateCommand()
                            Dim cmddlt As SqlCommand = con1.CreateCommand()
                            Dim cmddlthd As SqlCommand = con1.CreateCommand()
                            Using transaction As SqlTransaction = _
                              con1.BeginTransaction()
                                Using bulkCopy As SqlBulkCopy = New SqlBulkCopy(con1, SqlBulkCopyOptions.KeepIdentity, transaction)
                                    bulkCopy.BatchSize = 10
                                    bulkCopy.DestinationTableName = "tblvoters"
                                    cmd.Connection = con1
                                    cmd.Transaction = transaction

                                    cmddlt.Transaction = transaction
                                    cmddlt.Connection = con1

                                    cmddlthd.Transaction = transaction
                                    cmddlthd.Connection = con1

                                    Try
                                        'delete old list
                                        cmddlt.CommandText = "Delete from tblvoters where userId=@userid"
                                        cmddlt.Parameters.AddWithValue("@userid", tbxuserid.Text)
                                        cmddlt.ExecuteNonQuery()


                                        bulkCopy.WriteToServer(dt) 'bulkcopy to database

                                        ''set userid of voters
                                        cmd.CommandText = "UPDATE tblvoters  SET userID = @userid where userid=@null"
                                        cmd.Parameters.AddWithValue("@userid", tbxuserid.Text)
                                        cmd.Parameters.AddWithValue("@null", 0)
                                        cmd.ExecuteNonQuery()

                                        'delete headears
                                        cmddlthd.CommandText = "Delete from tblvoters where name =@name or indexno=@index or phone=@phone"
                                        cmddlthd.Parameters.AddWithValue("@name", "name")
                                        cmddlthd.Parameters.AddWithValue("@index", "index")
                                        cmddlthd.Parameters.AddWithValue("@phone", "phone")
                                        cmddlthd.ExecuteNonQuery()

                                        transaction.Commit()
                                    Catch ex As Exception
                                        transaction.Rollback()
                                    Finally
                                        con1.Close()
                                    End Try
                                End Using
                            End Using

                                Array.ForEach(Directory.GetFiles((Server.MapPath("csv/"))), AddressOf File.Delete)
                                ClientScript.RegisterStartupScript([GetType](), "alert", "alert('Imported successfully');", True)

                            Else
                                ClientScript.RegisterStartupScript([GetType](), "alert", "alert('Error, no csv file selected');", True)
                            End If

                    ElseIf lbxloadvters.Items.Count > 0 Then
                        tbxvotexist.Text = path
                        MultiView1.ActiveViewIndex = 7
                        End If

                  
                Else  'if data already exist 
                    ClientScript.RegisterStartupScript([GetType](), "alert", "alert('error, please import csv file only');", True)
                End If

            ElseIf sms.Text = "YES" Then
                ClientScript.RegisterStartupScript([GetType](), "alert", "alert('ERROR, Voterlist cannot be changed now, username and password mailed.');", True)
            End If

        End Using
    End Sub


    Protected Sub btnvotexist_Click(sender As Object, e As EventArgs) Handles btnvotexistok.Click
        'Try
        Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
           
            Dim dt As New DataTable()
            Dim line As String = Nothing
            Dim i As Integer = 0
            Using sr As StreamReader = File.OpenText(tbxvotexist.Text)
                line = sr.ReadLine()
                Do While line IsNot Nothing
                    Dim data() As String = line.Split(","c)
                    If data.Length > 0 Then
                        If i = 0 Then
                            For Each item In data
                                dt.Columns.Add(New DataColumn())
                            Next item
                            i += 1
                        End If
                        Dim row As DataRow = dt.NewRow()
                        row.ItemArray = data
                        dt.Rows.Add(row)
                    End If
                    line = sr.ReadLine()
                Loop
            End Using
            If dt.Rows.Count > 0 Then
                con1.Open()
                Dim cmd As SqlCommand = con1.CreateCommand()
                Dim cmddlt As SqlCommand = con1.CreateCommand()
                Dim cmddlthd As SqlCommand = con1.CreateCommand()
                Using transaction As SqlTransaction = _
                  con1.BeginTransaction()
                    Using bulkCopy As SqlBulkCopy = New SqlBulkCopy(con1, SqlBulkCopyOptions.KeepIdentity, transaction)
                        bulkCopy.BatchSize = 10
                        bulkCopy.DestinationTableName = "tblvoters"
                        cmd.Connection = con1
                        cmd.Transaction = transaction

                        cmddlt.Transaction = transaction
                        cmddlt.Connection = con1

                        cmddlthd.Transaction = transaction
                        cmddlthd.Connection = con1

                        Try
                            'delete old list
                            cmddlt.CommandText = "Delete from tblvoters where userId=@userid"
                            cmddlt.Parameters.AddWithValue("@userid", tbxuserid.Text)
                            cmddlt.ExecuteNonQuery()


                            bulkCopy.WriteToServer(dt) 'bulkcopy to database

                            ''set userid of voters
                            cmd.CommandText = "UPDATE tblvoters  SET userID = @userid where userid=@null"
                            cmd.Parameters.AddWithValue("@userid", tbxuserid.Text)
                            cmd.Parameters.AddWithValue("@null", 0)
                            cmd.ExecuteNonQuery()

                            'delete headears
                            cmddlthd.CommandText = "Delete from tblvoters where name =@name or indexno=@index or phone=@phone"
                            cmddlthd.Parameters.AddWithValue("@name", "name")
                            cmddlthd.Parameters.AddWithValue("@index", "index")
                            cmddlthd.Parameters.AddWithValue("@phone", "phone")
                            cmddlthd.ExecuteNonQuery()

                            transaction.Commit()
                        Catch ex As Exception
                            transaction.Rollback()
                        Finally
                            con1.Close()
                        End Try
                    End Using
                End Using
                MultiView1.ActiveViewIndex = 2
                Array.ForEach(Directory.GetFiles((Server.MapPath("csv/"))), AddressOf File.Delete)
                ClientScript.RegisterStartupScript([GetType](), "alert", "alert('Imported successfully');", True)
            Else
                ClientScript.RegisterStartupScript([GetType](), "alert", "alert('CSV file has no data');", True)
            End If

        End Using
        'Catch ex As Exception
        '    ScriptManager.RegisterStartupScript(UpdatePanel6, UpdatePanel6.GetType(), "alert", "alert('ERROR, please check data entry');", True)
        'End Try
    End Sub

    Protected Sub btnlistcancel_Click(sender As Object, e As EventArgs) Handles btnlistcancel.Click
        Try
            MultiView1.ActiveViewIndex = 2
            Array.ForEach(Directory.GetFiles((Server.MapPath("csv/"))), AddressOf File.Delete)

        Catch ex As Exception
        End Try
    End Sub

    Protected Sub btnviewprev_Click(sender As Object, e As EventArgs) Handles btnviewprev.Click
        Try
            If lbxvcand.SelectedIndex > 0 Then
                lbxvcand.SelectedIndex -= 1
                lbxvcand_SelectedIndexChanged1(lbxvcand, Nothing)
                btnviewnext.Enabled = True
                If lbxvcand.SelectedIndex = 0 Then
                    btnviewprev.Enabled = False
                End If

            End If

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub btnviewnext_Click(sender As Object, e As EventArgs) Handles btnviewnext.Click
        Try
            If lbxvcand.SelectedIndex < lbxvcand.Items.Count - 1 Then
                lbxvcand.SelectedIndex += 1
                btnviewprev.Enabled = True

                lbxvcand_SelectedIndexChanged1(lbxvcand, Nothing)
                If lbxvcand.SelectedIndex = lbxvcand.Items.Count - 1 Then
                    btnviewnext.Enabled = False
                End If

            End If

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub dbxstrtmnth_SelectedIndexChanged(sender As Object, e As EventArgs) Handles dbxstrtmnth.SelectedIndexChanged
        Try
            Tbxstartdate.Text = Format(CDate(dbxstrtmnth.SelectedValue.ToString & "/" & dbxstrtdate.SelectedValue.ToString & "/" & dbxstrtyr.SelectedValue.ToString), "MMM/dd/yyyy").ToString
        Catch ex As Exception
            lblerror.Text = "Invalid date"
        End Try
    End Sub

    Protected Sub dbxstrtdate_SelectedIndexChanged(sender As Object, e As EventArgs) Handles dbxstrtdate.SelectedIndexChanged
        Try
            Tbxstartdate.Text = Format(CDate(dbxstrtmnth.SelectedValue.ToString & "/" & dbxstrtdate.SelectedValue.ToString & "/" & dbxstrtyr.SelectedValue.ToString), "MMM/dd/yyyy").ToString

        Catch ex As Exception
            lblerror.Text = "Invalid date"
        End Try
    End Sub

    Protected Sub dbxstrtyr_SelectedIndexChanged(sender As Object, e As EventArgs) Handles dbxstrtyr.SelectedIndexChanged
        Try
            Tbxstartdate.Text = Format(CDate(dbxstrtmnth.SelectedValue.ToString & "/" & dbxstrtdate.SelectedValue.ToString & "/" & dbxstrtyr.SelectedValue.ToString), "MMM/dd/yyyy").ToString
        Catch ex As Exception
            lblerror.Text = "Invalid date"
        End Try
    End Sub


    Protected Sub dbxendmonth_SelectedIndexChanged(sender As Object, e As EventArgs) Handles dbxendmonth.SelectedIndexChanged
        Try
            tbxenddate.Text = Format(CDate(dbxendmonth.SelectedValue.ToString & "/" & dbxenddate.SelectedValue.ToString & "/" & dbxendyr.SelectedValue.ToString), "MMM/dd/yyyy").ToString
        Catch ex As Exception
            lblerror.Text = "Invalid date"
        End Try
    End Sub

    Protected Sub dbxenddate_SelectedIndexChanged(sender As Object, e As EventArgs) Handles dbxenddate.SelectedIndexChanged
        Try
            tbxenddate.Text = Format(CDate(dbxendmonth.SelectedValue.ToString & "/" & dbxenddate.SelectedValue.ToString & "/" & dbxendyr.SelectedValue.ToString), "MMM/dd/yyyy").ToString
        Catch ex As Exception
            lblerror.Text = "Invalid date"
        End Try
    End Sub


    Protected Sub dbxendyr_SelectedIndexChanged(sender As Object, e As EventArgs) Handles dbxendyr.SelectedIndexChanged
        Try
            tbxenddate.Text = Format(CDate(dbxendmonth.SelectedValue.ToString & "/" & dbxenddate.SelectedValue.ToString & "/" & dbxendyr.SelectedValue.ToString), "MMM/dd/yyyy").ToString
        Catch ex As Exception
            lblerror.Text = "Invalid date"
        End Try
    End Sub

    Protected Sub btnsave_Click(sender As Object, e As EventArgs) Handles btnsave.Click
        Try

            Tbxorgana.Text = Tbxorgana.Text.Replace("`", "").Replace("~", "").Replace("!", "") _
         .Replace("@", "").Replace("#", "").Replace("$", "").Replace("%", "").Replace("^", "") _
         .Replace("&", "").Replace("*", "").Replace("(", "").Replace(")", "").Replace("_", "").Replace("-", " ").Replace("+", "").Replace("=", "").Replace(";", "") _
         .Replace(":", "").Replace("/", "").Replace("'", "").Replace("?", "").Replace(".", "").Replace(">", "").Replace(",", "") _
         .Replace("<", "").Replace("[", "").Replace("{", "").Replace("}", "").Replace("]", "").Replace("\", "").Replace("|", "").Replace("}", "").Replace("""", "").Trim

            tbxtitle.Text = tbxtitle.Text.Replace("`", "").Replace("~", "").Replace("!", "") _
     .Replace("@", "").Replace("#", "").Replace("$", "").Replace("%", "").Replace("^", "") _
     .Replace("&", "").Replace("*", "").Replace("(", "").Replace(")", "").Replace("_", "").Replace("-", "").Replace("+", "").Replace("=", "").Replace(";", "") _
     .Replace(":", "").Replace("/", "").Replace("'", "").Replace("?", "").Replace(".", "").Replace(">", "").Replace(",", "") _
     .Replace("<", "").Replace("[", "").Replace("{", "").Replace("}", "").Replace("]", "").Replace("\", "").Replace("|", "").Replace("}", "").Replace("""", "").Trim


            Tbxstarttime.Text = tbxstrttim.Text
            tbxendtime.Text = tbxendtim.Text

            Dim strtdat As String = (CDate(Tbxstartdate.Text & " " & Tbxstarttime.Text)).ToString
            Dim enddat As String = (CDate(tbxenddate.Text & " " & tbxendtime.Text)).ToString

            Dim strttim As String = (DateAdd(DateInterval.Hour, -5, CDate(strtdat)))
            Dim endtim As String = (DateAdd(DateInterval.Hour, -5, CDate(enddat)))


            If CDate(strtdat).ToUniversalTime < CDate(enddat).ToUniversalTime And CDate(strtdat).ToUniversalTime >= Date.UtcNow Then
                Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
                    Dim query1 As String = "UPDATE signups SET schoolname = @schname, title=@title, starttime=@strt, endtime=@end  where id=@userid"
                    con1.Open()
                    Using cmd As New SqlCommand(query1, con1)
                        cmd.Parameters.AddWithValue("@schname", Tbxorgana.Text)
                        cmd.Parameters.AddWithValue("@userid", tbxuserid.Text)
                        cmd.Parameters.AddWithValue("@title", tbxtitle.Text)
                        cmd.Parameters.AddWithValue("@strt", strttim)
                        cmd.Parameters.AddWithValue("@end", endtim)
                        cmd.ExecuteNonQuery()
                    End Using
                    con1.Close()
                End Using
                ClientScript.RegisterStartupScript([GetType](), "alert", "alert('Save successful');", True)
            ElseIf CDate(strtdat).ToUniversalTime >= CDate(enddat).ToUniversalTime Then
                ClientScript.RegisterStartupScript([GetType](), "alert", "alert('Incorrect Duration settings');", True)
            End If

        Catch ex As Exception
            ClientScript.RegisterStartupScript([GetType](), "alert", "alert('Incorrect Duration settings');", True)
        End Try
    End Sub



    Protected Sub rbneditaccount_CheckedChanged(sender As Object, e As EventArgs) Handles rbneditaccount.CheckedChanged
        MultiView1.ActiveViewIndex = 9

        Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
            'check if password email is not sent
            Dim strt As New TextBox
            Dim endt As New TextBox
            Dim myReaderma As SqlDataReader = Nothing
            con1.Open()
            Dim queryma As String = "select  schoolname, title, starttime, endtime from signups where id=@userid"
            Dim myCommandma As New SqlCommand(queryma, con1)
            myCommandma.Parameters.AddWithValue("@userid", tbxuserid.Text)
            myReaderma = myCommandma.ExecuteReader()
            While myReaderma.Read()
                Tbxorgana.Text = (myReaderma(0).ToString())
                tbxtitle.Text = (myReaderma(1).ToString())
                strt.Text = (myReaderma(2).ToString())
                endt.Text = (myReaderma(3).ToString())
            End While
            con1.Close()
            dbxstrtdate.SelectedValue = Format(CDate(strt.Text).ToUniversalTime, "dd").ToString
            dbxstrtmnth.SelectedValue = Format(CDate(strt.Text).ToUniversalTime, "%M").ToString
            Tbxstartdate.Text = Format(CDate(strt.Text).ToUniversalTime, "MMM/dd/yyyy")
            dbxstrtyr.SelectedValue = Format(CDate(strt.Text).ToUniversalTime, "yyyy").ToString

            dbxenddate.SelectedValue = Format(CDate(endt.Text).ToUniversalTime, "dd").ToString
            dbxendmonth.SelectedValue = Format(CDate(endt.Text).ToUniversalTime, "%M").ToString
            tbxenddate.Text = Format(CDate(endt.Text).ToUniversalTime, "MMM/dd/yyyy")
            dbxendyr.SelectedValue = Format(CDate(endt.Text).ToUniversalTime, "yyyy").ToString


            tbxstrttim.Text = Format(CDate(strt.Text).ToUniversalTime, "HH:mm").ToString
            Tbxstarttime.Text = Format(CDate(strt.Text).ToUniversalTime, "HH:mm").ToString
            tbxenddate.Text = Format(CDate(endt.Text).ToUniversalTime, "MMM/dd/yyyy").ToString
            tbxendtime.Text = Format(CDate(endt.Text).ToUniversalTime, "HH:mm").ToString
            tbxendtim.Text = Format(CDate(endt.Text).ToUniversalTime, "HH:mm").ToString
        End Using

    End Sub


End Class