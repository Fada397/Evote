﻿Imports System.Data.SqlClient
Imports System.Configuration

Public Class Results
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            MultiView1.ActiveViewIndex = 0
        End If
    End Sub

    Protected Sub dbxpos_SelectedIndexChanged(sender As Object, e As EventArgs) Handles dbxpos.SelectedIndexChanged
        Try
            loadcandvotes()
            If dbxpos.SelectedIndex = dbxpos.Items.Count - 1 Then
                btnforwrd.Enabled = False
                btnback.Enabled = True
            ElseIf dbxpos.SelectedIndex = 0 Then
                btnback.Enabled = False
                btnforwrd.Enabled = True
            End If
            If dbxpos.SelectedIndex > 0 Then
                btnback.Enabled = True
            End If
        Catch ex As Exception
        End Try
    End Sub


    Protected Sub Loadpos()
        Try

            Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
                Dim dt As New DataTable()
                Dim myReader As SqlDataReader = Nothing

                'load all positions to listbox
                Dim lbx1 As New ListBox
                Dim tbx As New TextBox
                Dim obj As SqlCommand
                obj = con1.CreateCommand
                con1.Open()

                Dim cmd As SqlCommand = New SqlCommand("loadpos", con1) 'Specify that the SqlCommand is a stored procedure
                ' cmd.CommandType = System.Data.CommandType.StoredProcedure
                cmd.Connection = con1
                cmd.CommandText = "loadpos"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Parameters.AddWithValue("@userid", tbxadminuserid.Text)
                Dim sqlReader As SqlDataReader = cmd.ExecuteReader()
                dbxpos.DataSource = sqlReader
                dbxpos.DataTextField = "position"
                dbxpos.DataValueField = "Id"
                dbxpos.DataBind()
                sqlReader.Close()
                con1.Close()
                dbxpos.SelectedIndex = 0
            End Using
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub loadcandvotes()
        Try
            Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
                Dim dt As New DataTable()
                Dim myReader As SqlDataReader = Nothing

                'get candidate id and votesupdate
                Dim lbx As New ListBox
                Dim totalvotes As New TextBox
                con1.Open()
                Dim cmd As SqlCommand = New SqlCommand("getcandid", con1) 'Specify that the SqlCommand is a stored procedure
                cmd.Connection = con1
                cmd.CommandText = "getcandid"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Parameters.AddWithValue("@posid", dbxpos.SelectedValue.ToString)
                'cmd.Parameters.Add("@totalvotes", SqlDbType.Int)
                'cmd.Parameters("@totalvotes").Direction = ParameterDirection.Output
                Dim sqlReader1 As SqlDataReader = cmd.ExecuteReader()
                lbx.DataSource = sqlReader1
                lbx.DataTextField = "ID"
                lbx.DataValueField = "ID"
                lbx.DataBind()
                sqlReader1.Close()
                con1.Close()

                'get total votes from each position
                con1.Open()
                Dim cmdvt As SqlCommand = New SqlCommand("totalvotes", con1)
                cmdvt.Connection = con1
                cmdvt.CommandText = "totalvotes"
                cmdvt.CommandType = CommandType.StoredProcedure
                cmdvt.Parameters.AddWithValue("@posid", dbxpos.SelectedValue.ToString)
                Dim readt As SqlDataReader = Nothing
                readt = cmdvt.ExecuteReader
                While readt.Read
                    totalvotes.Text = readt(0).ToString
                End While
                readt.Close()
                con1.Close()

                'check if position has candidates 
                If lbx.Items.Count <> 0 Then
                    Dim totalvots As Integer = 0

                    lbx.SelectedIndex = -1
                    Do Until lbx.SelectedIndex = lbx.Items.Count - 1
                        con1.Open()
                        lbx.SelectedIndex += 1
                        Dim cmd1 As SqlCommand = New SqlCommand("loadcand", con1) 'Specify that the SqlCommand is a stored procedure
                        cmd1.Connection = con1
                        cmd1.CommandText = "loadcand"
                        cmd1.CommandType = CommandType.StoredProcedure
                        cmd1.Parameters.AddWithValue("@candid", lbx.SelectedValue.ToString)
                        Dim myReader1 As SqlDataReader = cmd1.ExecuteReader()

                        While myReader1.Read()
                            If (myReader1(1).ToString()) <> "" Then
                                ' tbxlast.Text = (myReader1(1).ToString())
                                Dim tbxn As New TextBox
                                Dim tbxv As New TextBox

                                tbxn.Text = (myReader1(0).ToString().ToUpper)
                                tbxn.Width = 280
                                tbxn.ForeColor = Drawing.Color.Black
                                tbxn.ReadOnly = True
                                tbxn.BorderStyle = BorderStyle.None
                                tbxn.Style.Add("text-align", "center")
                                tbxn.Style.Add("Font-Names", "Times New Roman")
                                tbxn.Font.Name = "Times New Roman"
                                tbxn.Enabled = False
                                tbxn.Font.Bold = True


                                tbxv.Text = (myReader1(3).ToString())
                                tbxv.Width = 170
                                tbxv.ForeColor = Drawing.Color.Black
                                tbxv.ReadOnly = True
                                tbxv.BorderStyle = BorderStyle.None
                                tbxv.Style.Add("margin-left", "100px")
                                tbxn.Font.Name = "Times New Roman"
                                tbxv.Enabled = False
                                tbxv.Font.Bold = True



                                Dim pane As New Panel
                                Dim imag As New Image
                                'pane.BorderWidth = 1
                                'pane.BorderColor = Drawing.Color.Black
                                rescandpanel.Controls.Add(pane)
                                If lbx.SelectedIndex Mod 2 = 1 Then
                                    pane.Style.Add("background-color", "#EEEEEE")
                                    tbxv.Style.Add("background-color", "#EEEEEE")
                                    tbxn.Style.Add("background-color", "#EEEEEE")
                                Else
                                    pane.Style.Add("background-color", "#E0E0E0")
                                    tbxv.Style.Add("background-color", "#E0E0E0")
                                    tbxn.Style.Add("background-color", "#E0E0E0")
                                End If

                                'calculate vote %
                                Dim lblxvp As New Label
                                lblxvp.ForeColor = Drawing.Color.Black
                                lblxvp.Style.Add("margin-left", "50px")
                                lblxvp.Font.Bold = True
                                tbxn.Font.Name = "Times New Roman"


                                'totalvots += tbxv.Text 'sum allthe votes for total votes for each position
                                ' totalvotes.Text = lbxt.SelectedItem.ToString
                                If totalvotes.Text = 0 Then
                                    tbxemptyb.Text = 0
                                Else
                                    tbxemptyb.Text = tbxvotturnout.Text - totalvotes.Text
                                End If

                                If totalvotes.Text = 0 Then
                                    lblxvp.Text = 0
                                ElseIf totalvotes.Text > 0 Then
                                    lblxvp.Text = Decimal.Round(CDec(tbxv.Text / totalvotes.Text) * 100, 2) & " %" 'calculat vote%
                                    ' lblxvp.Text = Decimal.Round(CDec(lbx.SelectedItem.ToString / totv) * 100, 2) & " %"
                                End If

                                imag.Width = 100
                                imag.Height = 90
                                imag.ImageAlign = ImageAlign.Middle
                                imag.BorderStyle = BorderStyle.Solid
                                imag.BorderWidth = 1
                                imag.Style.Add("margin-left", "90px")

                                pane.Controls.Add(tbxn)
                                pane.Controls.Add(imag)
                                pane.Controls.Add(tbxv)
                                pane.Controls.Add(lblxvp)

                                imag.ImageUrl = "~/databasepics/" & (myReader1(1).ToString())
                                ' Session("img") = "~/databasepics/" & (myReader1(2).ToString())

                            End If
                        End While
                        con1.Close()
                    Loop


                Else

                    If dbxpos.SelectedIndex = dbxpos.Items.Count - 1 Then
                        back_Click(btnback, Nothing) 'skip back when last position has no candidate
                    ElseIf dbxpos.SelectedIndex = 0 Then
                        btnforwrd_Click(btnforwrd, Nothing) 'skip forward when first position has no candidate
                    Else
                        If tbxskip.Text = "F" Then
                            btnforwrd_Click(btnforwrd, Nothing)
                        ElseIf tbxskip.Text = "B" Then
                            back_Click(btnback, Nothing)
                        End If
                    End If

                End If
            End Using

        Catch ex As Exception

        End Try
    End Sub



    Protected Sub refreshresults()
        Try
            dbxpos.Items.Insert(0, "select")
            Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
                Dim dt As New DataTable()
                Dim myReader As SqlDataReader = Nothing
                con1.Open()
                Dim vtout As New TextBox
                Dim lstdat As New TextBox
                Dim endtim As New TextBox
                Dim strttim As New TextBox
                Dim cmd1 As SqlCommand = New SqlCommand("resultgetuser", con1) 'Specify that the SqlCommand is a stored procedure
                cmd1.Connection = con1
                cmd1.CommandText = "resultgetuser"
                cmd1.CommandType = CommandType.StoredProcedure

                cmd1.Parameters.AddWithValue("@userid", tbxadminuserid.Text)


                cmd1.Parameters.Add("@starttime", SqlDbType.DateTime)
                cmd1.Parameters("@starttime").Direction = ParameterDirection.Output

                cmd1.Parameters.Add("@endtime", SqlDbType.DateTime)
                cmd1.Parameters("@endtime").Direction = ParameterDirection.Output

                cmd1.Parameters.Add("@lastupdate", SqlDbType.DateTime)
                cmd1.Parameters("@lastupdate").Direction = ParameterDirection.Output


                cmd1.Parameters.Add("@voteturnout", SqlDbType.NVarChar)
                cmd1.Parameters("@voteturnout").Direction = ParameterDirection.Output
                cmd1.Parameters("@voteturnout").Size = 20

                cmd1.Parameters.Add("@username", SqlDbType.NVarChar)
                cmd1.Parameters("@username").Direction = ParameterDirection.Output
                cmd1.Parameters("@username").Size = 50

                cmd1.Parameters.Add("@title", SqlDbType.NVarChar)
                cmd1.Parameters("@title").Direction = ParameterDirection.Output
                cmd1.Parameters("@title").Size = 100

                cmd1.Parameters.Add("@ID", SqlDbType.Int)
                cmd1.Parameters("@ID").Direction = ParameterDirection.Output

                myReader = cmd1.ExecuteReader()

                lstdat.Text = Convert.ToDateTime(cmd1.Parameters("@lastupdate").Value)
                endtim.Text = Convert.ToDateTime(cmd1.Parameters("@endtime").Value)
                strttim.Text = Convert.ToDateTime(cmd1.Parameters("@starttime").Value)
                vtout.Text = Convert.ToInt32(cmd1.Parameters("@voteturnout").Value)
                myReader.Close()
                con1.Close()

                con1.Open()
                'sign in to voters table to get registered voters
                Dim myCommandvt As SqlCommand = New SqlCommand("getallvoters", con1) 'Specify that the SqlCommand is a stored procedure
                myCommandvt.Connection = con1
                myCommandvt.CommandText = "getallvoters"
                myCommandvt.CommandType = CommandType.StoredProcedure
                Dim lbxvt As New ListBox
                myCommandvt.Parameters.AddWithValue("@userid", tbxadminuserid.Text)
                lbxvt.DataSource = myCommandvt.ExecuteReader
                lbxvt.DataTextField = "id"
                lbxvt.DataValueField = "id"
                lbxvt.DataBind()
                con1.Close()

                lstdat.Text = DateAdd(DateInterval.Minute, 20, CDate(lstdat.Text)) ''update if time is up 20min or voting time is over
                If Date.UtcNow > CDate(lstdat.Text).ToUniversalTime Or (Date.UtcNow >= CDate(endtim.Text).ToUniversalTime) Then

                    'update lastupdate votes all positions
                    autoupdate()

                    con1.Open()
                    ''sign in to voters table to get voter turnout i.e  all with votestatus  YES
                    Dim myCommandvst As SqlCommand = New SqlCommand("getvotestatus", con1)
                    myCommandvst.Connection = con1
                    myCommandvst.CommandText = "getvotestatus"
                    myCommandvst.CommandType = CommandType.StoredProcedure
                    Dim lbxvst As New ListBox
                    Dim vt As New TextBox
                    myCommandvst.Parameters.AddWithValue("@vt", "YES")
                    myCommandvst.Parameters.AddWithValue("userid", tbxadminuserid.Text)
                    lbxvst.DataSource = myCommandvst.ExecuteReader
                    lbxvst.DataTextField = "votesstatus"
                    lbxvst.DataValueField = "id"
                    lbxvst.DataBind()
                    vt.Text = lbxvst.Items.Count.ToString
                    con1.Close()


                    con1.Open()
                    'update the lastupdate time and voterturnout in signups 
                    Dim cmd As SqlCommand = New SqlCommand("turnoutupdate", con1) 'Specify that the SqlCommand is a stored procedure
                    cmd.Connection = con1
                    cmd.CommandText = "turnoutupdate"
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Parameters.AddWithValue("@userid", tbxadminuserid.Text)
                    cmd.Parameters.AddWithValue("@lastupdate", Date.Now.ToString)
                    cmd.Parameters.AddWithValue("@vturnout", vt.Text)
                    cmd.ExecuteNonQuery()
                    con1.Close()
                    vtout.Text = vt.Text 'pass current voterturnout
                End If

                If (Date.UtcNow >= CDate(endtim.Text).ToUniversalTime) Then  ''check if voting has ended
                    tbxendmsg.Text = "VOTING COMPLETED"
                ElseIf Date.Now >= CDate(strttim.Text) And Date.Now <= CDate(endtim.Text) Then
                    tbxendmsg.Text = "VOTING IN PROGRESS"
                Else
                    tbxendmsg.Text = "VOTING NOT STARTED"
                End If

                'get voterturnout from signups table (updated or not updated)
                Dim cmd2 As SqlCommand = New SqlCommand("resultgetuser", con1) 'Specify that the SqlCommand is a stored procedure
                Dim myReader1 As SqlDataReader = Nothing
                con1.Open()
                cmd2.Connection = con1
                cmd2.CommandText = "resultgetuser"
                cmd2.CommandType = CommandType.StoredProcedure
                cmd2.Parameters.AddWithValue("@userid", tbxadminuserid.Text)


                cmd2.Parameters.Add("@starttime", SqlDbType.DateTime)
                cmd2.Parameters("@starttime").Direction = ParameterDirection.Output

                cmd2.Parameters.Add("@endtime", SqlDbType.DateTime)
                cmd2.Parameters("@endtime").Direction = ParameterDirection.Output

                cmd2.Parameters.Add("@lastupdate", SqlDbType.DateTime)
                cmd2.Parameters("@lastupdate").Direction = ParameterDirection.Output


                cmd2.Parameters.Add("@voteturnout", SqlDbType.NVarChar)
                cmd2.Parameters("@voteturnout").Direction = ParameterDirection.Output
                cmd2.Parameters("@voteturnout").Size = 20

                cmd2.Parameters.Add("@username", SqlDbType.NVarChar)
                cmd2.Parameters("@username").Direction = ParameterDirection.Output
                cmd2.Parameters("@username").Size = 50

                cmd2.Parameters.Add("@title", SqlDbType.NVarChar)
                cmd2.Parameters("@title").Direction = ParameterDirection.Output
                cmd2.Parameters("@title").Size = 100

                cmd2.Parameters.Add("@ID", SqlDbType.Int)
                cmd2.Parameters("@ID").Direction = ParameterDirection.Output
                myReader1 = cmd2.ExecuteReader()
                con1.Close()
                vtout.Text = Convert.ToString(cmd2.Parameters("@voteturnout").Value)
                myReader1.Close()

                tbxregisterdvt.Text = lbxvt.Items.Count.ToString  'statistics ...registered voters
                If vtout.Text = 0 Then
                    tbxvturnpercent.Text = 0%
                    tbxvotturnout.Text = 0   'voterturnout
                    tbxemptyb.Text = 0
                Else
                    tbxvotturnout.Text = vtout.Text  'voterturnout
                    tbxvturnpercent.Text = Decimal.Round(CDec(tbxvotturnout.Text / tbxregisterdvt.Text) * 100, 2) & " %"  '...voterturnout %
                    tbxemptyb.Text = 0
                End If


                dbxpos.Items.RemoveAt(0)
                dbxpos.SelectedIndex = 0
                loadcandvotes()


                btnback.Enabled = False

                If dbxpos.Items.Count > 1 Then
                    btnforwrd.Enabled = True
                Else
                    btnforwrd.Enabled = False
                End If



            End Using
        Catch ex As Exception

        End Try
    End Sub


    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles btnRefresh.Click
        Try
            dbxpos.SelectedIndex = 0
            refreshresults()
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub autoupdate() ''''updates the votesupdate column of candidates in the various positions table
        Try

            Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
                con1.Open()
                Dim cmd As SqlCommand = New SqlCommand("resultupdate", con1) 'Specify that the SqlCommand is a stored procedure
                cmd.Connection = con1
                cmd.CommandText = "resultupdate"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Parameters.AddWithValue("@userid", tbxadminuserid.Text)
                cmd.ExecuteReader()
                con1.Close()
            End Using
        Catch ex As Exception

        End Try
    End Sub


    Protected Sub Btnlogin_Click(sender As Object, e As EventArgs) Handles Btnlogin.Click
        Try
            tbxusername.Text = tbxusername.Text.Replace("`", "").Replace("~", "").Replace("!", "") _
               .Replace("@", "").Replace("#", "").Replace("$", "").Replace("%", "").Replace("^", "") _
               .Replace("&", "").Replace("*", "").Replace("(", "").Replace(")", "").Replace("+", "").Replace("=", "").Replace(";", "") _
               .Replace(":", "").Replace("/", "").Replace("'", "").Replace("?", "").Replace(".", "").Replace(">", "").Replace(",", "") _
               .Replace("<", "").Replace("[", "").Replace("{", "").Replace("}", "").Replace("]", "").Replace("\", "").Replace("|", "").Replace("}", "").Replace("""", "").Trim

            tbxpassword.Text = tbxpassword.Text.Replace("`", "").Replace("~", "").Replace("!", "") _
               .Replace("_", "").Replace("-", "").Replace("@", "").Replace("#", "").Replace("$", "").Replace("%", "").Replace("^", "") _
              .Replace("&", "").Replace("*", "").Replace("(", "").Replace(")", "").Replace("+", "").Replace("=", "").Replace(";", "") _
              .Replace(":", "").Replace("/", "").Replace("'", "").Replace("?", "").Replace(".", "").Replace(">", "").Replace(",", "") _
              .Replace("<", "").Replace("[", "").Replace("{", "").Replace("}", "").Replace("]", "").Replace("\", "").Replace("|", "").Replace("}", "").Replace("""", "").Trim

            Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
                Dim dt As New DataTable()
                Dim myReader As SqlDataReader = Nothing
                Dim myReader1 As SqlDataReader = Nothing

                'get account id
                con1.Open()
                Dim cmdid As SqlCommand = New SqlCommand("resultuserid", con1)
                cmdid.Connection = con1
                cmdid.CommandText = "resultuserid"
                cmdid.CommandType = CommandType.StoredProcedure
                cmdid.Parameters.AddWithValue("@voterusername", tbxusername.Text)
                cmdid.Parameters.AddWithValue("@voterpassword", tbxpassword.Text)
                Dim lbxres As New ListBox
                lbxres.DataSource = cmdid.ExecuteReader
                lbxres.DataTextField = "userID"
                lbxres.DataValueField = "userID"
                lbxres.DataBind()
                con1.Close()

                If lbxres.Items.Count = 1 Then
                    lbxres.SelectedIndex = 0
                    tbxadminuserid.Text = lbxres.SelectedItem.ToString
                    con1.Open()
                    'get username of school from signups table and 
                    Dim sch As New TextBox
                    Dim title As New TextBox
                    Dim userid As New TextBox

                    Dim cmd1 As SqlCommand = New SqlCommand("resultgetuser", con1) 'Specify that the SqlCommand is a stored procedure
                    cmd1.Connection = con1
                    cmd1.CommandText = "resultgetuser"
                    cmd1.CommandType = CommandType.StoredProcedure
                    cmd1.Parameters.AddWithValue("@userid", tbxadminuserid.Text)

                    cmd1.Parameters.Add("@starttime", SqlDbType.DateTime)
                    cmd1.Parameters("@starttime").Direction = ParameterDirection.Output

                    cmd1.Parameters.Add("@endtime", SqlDbType.DateTime)
                    cmd1.Parameters("@endtime").Direction = ParameterDirection.Output

                    cmd1.Parameters.Add("@lastupdate", SqlDbType.DateTime)
                    cmd1.Parameters("@lastupdate").Direction = ParameterDirection.Output


                    cmd1.Parameters.Add("@voteturnout", SqlDbType.NVarChar)
                    cmd1.Parameters("@voteturnout").Direction = ParameterDirection.Output
                    cmd1.Parameters("@voteturnout").Size = 20

                    cmd1.Parameters.Add("@username", SqlDbType.NVarChar)
                    cmd1.Parameters("@username").Direction = ParameterDirection.Output
                    cmd1.Parameters("@username").Size = 50

                    cmd1.Parameters.Add("@title", SqlDbType.NVarChar)
                    cmd1.Parameters("@title").Direction = ParameterDirection.Output
                    cmd1.Parameters("@title").Size = 100

                    cmd1.Parameters.Add("@ID", SqlDbType.Int)
                    cmd1.Parameters("@ID").Direction = ParameterDirection.Output

                    myReader = cmd1.ExecuteReader()
                    con1.Close()
                    tbxadminuserid.Text = Convert.ToString(cmd1.Parameters("@userid").Value)
                    If tbxadminuserid.Text <> "" Then
                        tbxadminusername.Text = Convert.ToString(cmd1.Parameters("@username").Value)
                        title.Text = Convert.ToString(cmd1.Parameters("@title").Value)

                        MultiView1.ActiveViewIndex = 1
                        tbxrestitle.Text = title.Text
                        Loadpos()
                        btnback.Enabled = False
                        'dbxpos.SelectedIndex = 0
                        refreshresults()
                        If dbxpos.SelectedIndex = dbxpos.Items.Count - 1 Then 'if jumps to select last item
                            btnforwrd.Enabled = False
                            If dbxpos.Items.Count > 1 Then
                                btnback.Enabled = True
                            End If
                        End If
                    ElseIf tbxadminusername.Text = "" Then
                        'ClientScript.RegisterStartupScript([GetType](), "alert", "alert('Incorrect Username');", True)
                        ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "alert", "alert('Incorrect Username');", True)
                        '    
                    End If
                    myReader.Close()
                ElseIf lbxres.Items.Count > 1 Then
                    'direct to select account   resultuseridname
                    Do Until lbxres.SelectedIndex = lbxres.Items.Count - 1
                        lbxres.SelectedIndex += 1
                        con1.Open()
                        Dim cmd As SqlCommand = New SqlCommand("resultuseridname", con1)
                        cmd.Connection = con1
                        cmd.CommandText = "resultuseridname"
                        cmd.CommandType = CommandType.StoredProcedure
                        cmd.Parameters.AddWithValue("@userid", lbxres.SelectedItem.ToString)
                        Dim lbxresslt As New ListBox
                        lbxresslt.DataSource = cmd.ExecuteReader
                        lbxresslt.DataTextField = "title"
                        lbxresslt.DataValueField = "ID"
                        lbxresslt.DataBind()
                        con1.Close()
                        lbxresslt.SelectedIndex = 0

                        lbxreslog.Items.Add(lbxresslt.SelectedItem.ToString)
                        lbxreslog.SelectedIndex = lbxreslog.Items.Count - 1
                        lbxreslog.SelectedItem.Value = lbxresslt.SelectedValue.ToString
                    Loop
                    lbxreslog.SelectedIndex = -1
                    MultiView1.ActiveViewIndex = 3
                ElseIf lbxres.Items.Count < 1 Then 'not exist
                    ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "alert", "alert('Incorrect Username or password');", True)
                End If
            End Using
        Catch ex As Exception
            ClientScript.RegisterStartupScript([GetType](), "alert", "alert('Incorrect Username');", True)
        End Try

    End Sub

    Protected Sub back_Click(sender As Object, e As System.Web.UI.ImageClickEventArgs) Handles btnback.Click
        Try
            tbxskip.Text = "B"
            If dbxpos.SelectedIndex > 0 Then
                dbxpos.SelectedIndex -= 1
                loadcandvotes()
            End If
            If dbxpos.SelectedIndex = 0 Then
                btnback.Enabled = False
            End If
            btnforwrd.Enabled = True
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub btnforwrd_Click(sender As Object, e As System.Web.UI.ImageClickEventArgs) Handles btnforwrd.Click
        Try
            tbxskip.Text = "F"
            If dbxpos.SelectedIndex < dbxpos.Items.Count - 1 Then
                dbxpos.SelectedIndex += 1
                loadcandvotes()
                If dbxpos.SelectedIndex = dbxpos.Items.Count - 1 Then
                    btnforwrd.Enabled = False
                End If
            ElseIf dbxpos.SelectedIndex = dbxpos.Items.Count - 1 Then
                btnforwrd.Enabled = False
            End If
            btnback.Enabled = True
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub btnselectlog_Click(sender As Object, e As EventArgs) Handles btnselectlog.Click
        Try
            Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
                Dim dt As New DataTable()
                Dim myReader As SqlDataReader = Nothing
                Dim myReader1 As SqlDataReader = Nothing


                tbxadminuserid.Text = lbxreslog.SelectedValue.ToString
                con1.Open()
                'get username of school from signups table and 
                Dim sch As New TextBox
                Dim title As New TextBox
                Dim userid As New TextBox

                Dim cmd1 As SqlCommand = New SqlCommand("resultgetuser", con1) 'Specify that the SqlCommand is a stored procedure
                cmd1.Connection = con1
                cmd1.CommandText = "resultgetuser"
                cmd1.CommandType = CommandType.StoredProcedure
                cmd1.Parameters.AddWithValue("@userid", tbxadminuserid.Text)


                cmd1.Parameters.Add("@starttime", SqlDbType.DateTime)
                cmd1.Parameters("@starttime").Direction = ParameterDirection.Output

                cmd1.Parameters.Add("@endtime", SqlDbType.DateTime)
                cmd1.Parameters("@endtime").Direction = ParameterDirection.Output

                cmd1.Parameters.Add("@lastupdate", SqlDbType.DateTime)
                cmd1.Parameters("@lastupdate").Direction = ParameterDirection.Output


                cmd1.Parameters.Add("@voteturnout", SqlDbType.NVarChar)
                cmd1.Parameters("@voteturnout").Direction = ParameterDirection.Output
                cmd1.Parameters("@voteturnout").Size = 20

                cmd1.Parameters.Add("@username", SqlDbType.NVarChar)
                cmd1.Parameters("@username").Direction = ParameterDirection.Output
                cmd1.Parameters("@username").Size = 50

                cmd1.Parameters.Add("@title", SqlDbType.NVarChar)
                cmd1.Parameters("@title").Direction = ParameterDirection.Output
                cmd1.Parameters("@title").Size = 100

                cmd1.Parameters.Add("@ID", SqlDbType.Int)
                cmd1.Parameters("@ID").Direction = ParameterDirection.Output

                myReader = cmd1.ExecuteReader()

                con1.Close()
                tbxadminuserid.Text = Convert.ToString(cmd1.Parameters("@userid").Value)
                If tbxadminuserid.Text <> "" Then
                    tbxadminusername.Text = Convert.ToString(cmd1.Parameters("@username").Value)
                    title.Text = Convert.ToString(cmd1.Parameters("@title").Value)

                    MultiView1.ActiveViewIndex = 1
                    tbxrestitle.Text = title.Text
                    Loadpos()
                    btnback.Enabled = False
                    'dbxpos.SelectedIndex = 0
                    refreshresults()
                    If dbxpos.SelectedIndex = dbxpos.Items.Count - 1 Then 'if jumps to select last item
                        btnforwrd.Enabled = False
                        If dbxpos.Items.Count > 1 Then
                            btnback.Enabled = True
                        End If
                    End If
                End If
                myReader.Close()
            End Using
        Catch ex As Exception

        End Try
    End Sub


End Class