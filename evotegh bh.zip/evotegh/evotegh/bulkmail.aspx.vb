﻿Imports System.Data.SqlClient
Imports System.Security.Cryptography
Imports System.Net
Imports System.IO

Public Class manifesto1
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
        End If
    End Sub

    Protected Sub btnsbmit_Click(sender As Object, e As EventArgs) Handles btnsbmit.Click

        Try

            'If tbxsmscode.Text.Trim = tsms.Text Then
            '    If rbnspecify.Checked = True Then
            '        tsmsnumber.Text = Tbxsmsnumber.Text
            '    End If
            Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
                'select candidate with refno
                con1.Open()
                Dim ID As New TextBox
                Dim myreaderch As SqlDataReader = Nothing
                Dim querych As String = "select id from tblcand where refno = @ref"
                Dim myCommandch As New SqlCommand(querych, con1)
                myCommandch.Parameters.AddWithValue("@ref", tbxref.Text)
                myreaderch = myCommandch.ExecuteReader()
                While myreaderch.Read()
                    ID.Text = (myreaderch(0).ToString())
                End While
                con1.Close()

                If ID.Text <> "" Then

                    'check if request already made
                    con1.Open()
                    Dim reqID As New TextBox
                    Dim myreaderch1 As SqlDataReader = Nothing
                    Dim querych1 As String = "select id from tblsmsrequest where candID = @candID"
                    Dim myCommandch1 As New SqlCommand(querych1, con1)
                    myCommandch1.Parameters.AddWithValue("@candID", ID.Text)
                    myreaderch1 = myCommandch1.ExecuteReader()
                    While myreaderch1.Read()
                        reqID.Text = (myreaderch1(0).ToString())
                    End While
                    con1.Close()

                    If reqID.Text = "" Then
                        Dim hasfil As String = "NO"
                        If flpcamp.HasFile Then
                            hasfil = "YES"
                            'or  FileUpload1.FileName.ToString <> "" Then
                            Dim filextension As String = System.IO.Path.GetExtension(flpcamp.FileName) 'restrict to pdf only
                            If filextension.ToLower() = ".pdf" Then
                                Dim filesize As Integer = flpcamp.PostedFile.ContentLength     'set maximum filesize
                                If filesize > 5242880 Then        ' filesize in bytes..1MB=1024 *1024 bytes  ....5MB = (1024*1024)*5
                                    lblmsg.Text = "Maximum file size exceeded"
                                Else
                                    flpcamp.SaveAs(Server.MapPath("~/manifesto/" & tbxref.Text)) 'save file
                                    Dim query As String = "insert into tblsmsrequest values (@attach, @candID, @message, @requestdate, @lastindex, @tit)"
                                    Dim myCommand As New SqlCommand(query, con1)
                                    myCommand.Parameters.AddWithValue("@attach", hasfil)
                                    myCommand.Parameters.AddWithValue("@candID", ID.Text)
                                    myCommand.Parameters.AddWithValue("@message", tbxmsg.Text)
                                    myCommand.Parameters.AddWithValue("@lastindex", "-1")
                                    myCommand.Parameters.AddWithValue("@requestdate", Date.UtcNow)
                                    myCommand.Parameters.AddWithValue("@tit", tbxtitle.Text)
                                    con1.Open()
                                    myCommand.ExecuteNonQuery()
                                    con1.Close()
                                End If
                            End If

                        ElseIf flpcamp.HasFile = False Then  'has no file.. just save
                            Dim query As String = "insert into tblsmsrequest values (@attach, @candID, @message, @requestdate, @lastindex, @tit)"
                            Dim myCommand As New SqlCommand(query, con1)
                            myCommand.Parameters.AddWithValue("@attach", hasfil)
                            myCommand.Parameters.AddWithValue("@candID", ID.Text)
                            myCommand.Parameters.AddWithValue("@message", tbxmsg.Text)
                            myCommand.Parameters.AddWithValue("@lastindex", "-1")
                            myCommand.Parameters.AddWithValue("@requestdate", Date.UtcNow)
                            myCommand.Parameters.AddWithValue("@tit", tbxtitle.Text)
                             con1.Open()
                            myCommand.ExecuteNonQuery()
                            con1.Close()
                        End If

                        tbxmsg.Text = ""
                        tbxref.Text = ""
                        tbxmsg.Text = ""
                        lblmsg.Text = "Request Successfully Sent"
                        lblmsg.ForeColor = Drawing.Color.Green

                        'sms to notify us***********
                        smsevote()

                    ElseIf reqID.Text <> "" Then
                        'update message




                        Dim hasfil As String = "NO"
                        If flpcamp.HasFile Then
                            hasfil = "YES"
                            'or  FileUpload1.FileName.ToString <> "" Then
                            Dim filextension As String = System.IO.Path.GetExtension(flpcamp.FileName) 'restrict to pdf only
                            If filextension.ToLower() = ".pdf" Then
                                Dim filesize As Integer = flpcamp.PostedFile.ContentLength     'set maximum filesize
                                If filesize > 5242880 Then        ' filesize in bytes..1MB=1024 *1024 bytes  ....5MB = (1024*1024)*5
                                    ClientScript.RegisterStartupScript([GetType](), "alert", "alert('maximum filesize(5MB) exceeded');", True) 'maximum filesize(2MB) exceeded"
                                Else
                                    flpcamp.SaveAs(Server.MapPath("~/manifesto/" & tbxref.Text)) 'save file
                                    Dim query As String = "UPDATE tblsmsrequest set message = @message, tit= @title where ID = @id"
                                    Dim myCommand As New SqlCommand(query, con1)
                                    myCommand.Parameters.AddWithValue("@ID", reqID.Text)
                                    myCommand.Parameters.AddWithValue("@message", tbxmsg.Text)
                                    myCommand.Parameters.AddWithValue("@title", tbxtitle.Text)
                                    con1.Open()
                                    myCommand.ExecuteNonQuery()
                                    con1.Close()
                                End If
                            End If

                        ElseIf flpcamp.HasFile = False Then  'has no file.. just save

                            Dim query As String = "UPDATE tblsmsrequest set message = @message, tit= @title where ID = @id"
                            Dim myCommand As New SqlCommand(query, con1)
                            myCommand.Parameters.AddWithValue("@ID", reqID.Text)
                            myCommand.Parameters.AddWithValue("@message", tbxmsg.Text)
                            myCommand.Parameters.AddWithValue("@title", tbxtitle.Text)
                            con1.Open()
                            myCommand.ExecuteNonQuery()
                            con1.Close()

                        End If
                        tbxmsg.Text = ""
                        tbxref.Text = ""
                        tbxmsg.Text = ""
                        lblmsg.Text = "Request Successfully Sent"
                        lblmsg.ForeColor = Drawing.Color.Green

                        'sms to notify evoteGH ***********
                        smsevote()

                    End If
                ElseIf ID.Text = "" Then
                    lblmsg.Text = "Incorrect Reference Number entered"
                    lblmsg.ForeColor = Drawing.Color.Red
                End If

            End Using




        Catch ex As Exception
            lblmsg.Text = "Error sending request"
            lblmsg.ForeColor = Drawing.Color.Red
        End Try

    End Sub

    Private Sub smsevote()
        Try
            ' Dim url As String = "https://api.smsgh.com/v3/messages/send?" + "From=Evotegh&To=%2B233203712650" + "&Content=New bulk mail requst" + "&ClientId=vfwdjpjt" + "&ClientSecret=lysnrxhf" + "&RegisteredDelivery=true"

            Dim url As String = "https://api.smsgh.com/v3/messages/send?" + "From=Evotegh&To=%2B233203712650" + "&Content=New bulk mail request" + "&ClientId=vfwdjpjt" + "&ClientSecret=lysnrxhf" + "&RegisteredDelivery=true"
            Dim client As New WebClient()
            Dim text As String = client.DownloadString(url)
        Catch ex As Exception

        End Try
    End Sub










 
End Class