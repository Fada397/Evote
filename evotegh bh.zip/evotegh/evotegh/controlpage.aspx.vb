﻿Imports System.Data.SqlClient
Imports System.IO
Imports System.Data.Common
Imports System.Data.OleDb
Imports System.Security.Cryptography
Imports System.Net.Mail
Imports System.Configuration
Imports System.Net
Imports System.Web.Mail



Public Class controlpage
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            signupsall()
            RadioButton1.Checked = True
            btnaccount_Click(btnaccount, Nothing)
        End If
    End Sub

    Protected Sub expiredaccount()
        lbxusernme.Items.Clear()
        Dim expdate As New TextBox
        expdate.Text = CDate(DateAdd(DateInterval.Day, -14, Date.UtcNow)).ToString
        Try
            Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
                Dim obj As SqlCommand
                obj = con1.CreateCommand
                con1.Open()

                Dim lbxcode As New ListBox
                Dim tbxusenam As New ListBox
                Dim dept As New ListBox

                Dim query As String = "select * from signups where endtime < @endtim"
                Dim myCommand As New SqlCommand(query, con1)
                myCommand.Parameters.AddWithValue("@endtim", CDate(expdate.Text))

                lbxcode.DataSource = myCommand.ExecuteReader
                lbxcode.DataTextField = "code"
                lbxcode.DataValueField = "Id"
                lbxcode.DataBind()
                con1.Close()

                con1.Open()
                tbxusenam.DataSource = myCommand.ExecuteReader
                tbxusenam.DataTextField = "schoolname"
                tbxusenam.DataValueField = "Id"
                tbxusenam.DataBind()
                con1.Close()

                con1.Open()
                dept.DataSource = myCommand.ExecuteReader
                dept.DataTextField = "title"
                dept.DataValueField = "Id"
                dept.DataBind()
                con1.Close()

                lbxusernme.Items.Add("Select")
                lbxcode.SelectedIndex = -1
                tbxusenam.SelectedIndex = -1
                dept.SelectedIndex = -1
                Do Until lbxcode.SelectedIndex = lbxcode.Items.Count - 1
                    lbxcode.SelectedIndex += 1
                    tbxusenam.SelectedIndex += 1
                    dept.SelectedIndex += 1

                    Dim text1 As New TextBox
                    Dim text2 As New TextBox
                    Dim text3 As New TextBox
                    text1.Text = lbxcode.SelectedItem.ToString
                    text2.Text = tbxusenam.SelectedItem.ToString
                    text3.Text = dept.SelectedItem.ToString
                    lbxusernme.Items.Add(text1.Text & "-" & text2.Text & "-" & text3.Text)
                Loop

                lbxusernme.SelectedValue = ""
            End Using
        Catch ex As Exception

        End Try



    End Sub





    Protected Sub Un_signupauthenticated()
        Try

            lbxusernme.Items.Clear()

            Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
                Dim obj As SqlCommand
                obj = con1.CreateCommand
                con1.Open()

                Dim lbxcode As New ListBox
                Dim tbxusenam As New ListBox
                Dim dept As New ListBox

                Dim query As String = "select * from signups where authenticate=@auth"
                Dim myCommand As New SqlCommand(query, con1)
                myCommand.Parameters.AddWithValue("@auth", "NO")

                lbxcode.DataSource = myCommand.ExecuteReader
                lbxcode.DataTextField = "code"
                lbxcode.DataValueField = "Id"
                lbxcode.DataBind()
                con1.Close()

                con1.Open()
                tbxusenam.DataSource = myCommand.ExecuteReader
                tbxusenam.DataTextField = "schoolname"
                tbxusenam.DataValueField = "Id"
                tbxusenam.DataBind()
                con1.Close()

                con1.Open()
                dept.DataSource = myCommand.ExecuteReader
                dept.DataTextField = "title"
                dept.DataValueField = "Id"
                dept.DataBind()
                con1.Close()

                lbxusernme.Items.Add("Select")
                lbxcode.SelectedIndex = -1
                tbxusenam.SelectedIndex = -1
                dept.SelectedIndex = -1
                Do Until lbxcode.SelectedIndex = lbxcode.Items.Count - 1
                    lbxcode.SelectedIndex += 1
                    tbxusenam.SelectedIndex += 1
                    dept.SelectedIndex += 1

                    Dim text1 As New TextBox
                    Dim text2 As New TextBox
                    Dim text3 As New TextBox
                    text1.Text = lbxcode.SelectedItem.ToString
                    text2.Text = tbxusenam.SelectedItem.ToString
                    text3.Text = dept.SelectedItem.ToString
                    lbxusernme.Items.Add(text1.Text & "-" & text2.Text & "-" & text3.Text)
                Loop

                lbxusernme.SelectedValue = ""
            End Using
        Catch ex As Exception

        End Try
    End Sub





    Protected Sub Signupauthenticated()
        lbxusernme.Items.Clear()
        Try

            Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
                Dim obj As SqlCommand
                obj = con1.CreateCommand
                con1.Open()

                Dim lbxcode As New ListBox
                Dim tbxusenam As New ListBox
                Dim dept As New ListBox

                Dim query As String = "select * from signups where authenticate= @auth"
                Dim myCommand As New SqlCommand(query, con1)
                myCommand.Parameters.AddWithValue("@auth", "YES")

                lbxcode.DataSource = myCommand.ExecuteReader
                lbxcode.DataTextField = "code"
                lbxcode.DataValueField = "Id"
                lbxcode.DataBind()
                con1.Close()

                con1.Open()
                tbxusenam.DataSource = myCommand.ExecuteReader
                tbxusenam.DataTextField = "schoolname"
                tbxusenam.DataValueField = "Id"
                tbxusenam.DataBind()
                con1.Close()

                con1.Open()
                dept.DataSource = myCommand.ExecuteReader
                dept.DataTextField = "title"
                dept.DataValueField = "Id"
                dept.DataBind()
                con1.Close()

                lbxusernme.Items.Add("Select")
                lbxcode.SelectedIndex = -1
                tbxusenam.SelectedIndex = -1
                dept.SelectedIndex = -1
                Do Until lbxcode.SelectedIndex = lbxcode.Items.Count - 1
                    lbxcode.SelectedIndex += 1
                    tbxusenam.SelectedIndex += 1
                    dept.SelectedIndex += 1

                    Dim text1 As New TextBox
                    Dim text2 As New TextBox
                    Dim text3 As New TextBox
                    text1.Text = lbxcode.SelectedItem.ToString
                    text2.Text = tbxusenam.SelectedItem.ToString
                    text3.Text = dept.SelectedItem.ToString
                    lbxusernme.Items.Add(text1.Text & "-" & text2.Text & "-" & text3.Text)
                Loop

                lbxusernme.SelectedValue = ""
            End Using
        Catch ex As Exception

        End Try



    End Sub





    Protected Sub signupsall()
        lbxusernme.Items.Clear()

        Try

            Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
                Dim obj As SqlCommand
                obj = con1.CreateCommand
                con1.Open()

                Dim lbxcode As New ListBox
                Dim tbxusenam As New ListBox
                Dim dept As New ListBox

                Dim query As String = "select * from signups "
                Dim myCommand As New SqlCommand(query, con1)


                lbxcode.DataSource = myCommand.ExecuteReader
                lbxcode.DataTextField = "code"
                lbxcode.DataValueField = "Id"
                lbxcode.DataBind()
                con1.Close()

                con1.Open()
                tbxusenam.DataSource = myCommand.ExecuteReader
                tbxusenam.DataTextField = "schoolname"
                tbxusenam.DataValueField = "Id"
                tbxusenam.DataBind()
                con1.Close()

                con1.Open()
                dept.DataSource = myCommand.ExecuteReader
                dept.DataTextField = "title"
                dept.DataValueField = "Id"
                dept.DataBind()
                con1.Close()

                lbxusernme.Items.Add("Select")
                lbxcode.SelectedIndex = -1
                tbxusenam.SelectedIndex = -1
                dept.SelectedIndex = -1
                Do Until lbxcode.SelectedIndex = lbxcode.Items.Count - 1
                    lbxcode.SelectedIndex += 1
                    tbxusenam.SelectedIndex += 1
                    dept.SelectedIndex += 1

                    Dim text1 As New TextBox
                    Dim text2 As New TextBox
                    Dim text3 As New TextBox
                    text1.Text = lbxcode.SelectedItem.ToString
                    text2.Text = tbxusenam.SelectedItem.ToString
                    text3.Text = dept.SelectedItem.ToString
                    lbxusernme.Items.Add(text1.Text & "-" & text2.Text & "-" & text3.Text)
                Loop

                lbxusernme.SelectedValue = ""
            End Using
        Catch ex As Exception

        End Try

    End Sub

    Protected Sub loadinfo()
        Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
            Dim dt As New DataTable()
            con1.Open()
            Dim myReader As SqlDataReader = Nothing

            Dim code As New TextBox
            code.Text = Mid(lbxusernme.SelectedItem.ToString, 1, 4)
            Dim query As String = "select * from signups where code= '" + code.Text + "' "    'show first item
            Dim myCommand As New SqlCommand(query, con1)
            myReader = myCommand.ExecuteReader()
            While myReader.Read()
                tbxorg.Text = (myReader(1).ToString())
                Tbxbalotname.Text = (myReader(2).ToString())
                tbxusername.Text = (myReader(3).ToString())
                tbxpassword.Text = (myReader(4).ToString())
                tbxCode.Text = (myReader(5).ToString())
                tbxstarttime.Text = CDate(myReader(6).ToString()).ToUniversalTime.ToString
                tbxEndTime.Text = CDate(myReader(7).ToString()).ToUniversalTime.ToString
                tbxAuthenticate.Text = (myReader(8).ToString())
                ' tbxadminname.text = (myReader(11).ToString())
                tbxEmail.Text = (myReader(12).ToString())
                tbxphone.Text = (myReader(13).ToString())
                tbxid.Text = (myReader(0).ToString())
            End While
            con1.Close()

        End Using
    End Sub

    Protected Sub lbxusernme_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lbxusernme.SelectedIndexChanged
        loadinfo()
        If lbxusernme.SelectedIndex = 0 Then
            tbxorg.Text = ""
            Tbxbalotname.Text = ""
            tbxusername.Text = ""
            tbxpassword.Text = ""
            tbxCode.Text = ""
            tbxstarttime.Text = ""
            tbxEndTime.Text = ""
            tbxAuthenticate.Text = ""
            tbxEmail.Text = ""
            tbxphone.Text = ""
            tbxid.Text = ""
        End If
        tbxheader.Text = (tbxorg.Text & "-" & Tbxbalotname.Text).ToUpper
    End Sub

    Protected Sub btnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        If lbxusernme.SelectedIndex < lbxusernme.Items.Count - 1 Then
            lbxusernme.SelectedIndex += 1
            loadinfo()
        End If
        tbxheader.Text = (tbxorg.Text & "-" & Tbxbalotname.Text).ToUpper
    End Sub

    Protected Sub btnPrevious_Click(sender As Object, e As EventArgs) Handles btnPrevious.Click
        If lbxusernme.SelectedIndex >= 0 Then
            lbxusernme.SelectedIndex -= 1
            loadinfo()
        End If

        If lbxusernme.SelectedIndex = 0 Then
            tbxorg.Text = ""
            Tbxbalotname.Text = ""
            tbxusername.Text = ""
            tbxpassword.Text = ""
            tbxCode.Text = ""
            tbxstarttime.Text = ""
            tbxEndTime.Text = ""
            tbxAuthenticate.Text = ""
        End If
        tbxheader.Text = (tbxorg.Text & "-" & Tbxbalotname.Text).ToUpper
    End Sub


    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles btnshowpas.Click
        If tbxpassword.ForeColor = Drawing.Color.White Then
            tbxpassword.ForeColor = Drawing.Color.Black
            btnshowpas.Text = "Hide Password"
        ElseIf tbxpassword.ForeColor = Drawing.Color.Black Then
            tbxpassword.ForeColor = Drawing.Color.White
            btnshowpas.Text = "Show Password"
        End If
    End Sub



    Protected Sub Export_Voters_Click(sender As Object, e As EventArgs) Handles Export_Voters.Click
        ' Try
        Dim con As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
        Dim ss As String = "select * from tblvoters where userid=@userid"
        Dim myCommand As New SqlCommand(ss, con)
        myCommand.Parameters.AddWithValue("@userid", tbxid.Text)
        Dim da As New SqlDataAdapter(myCommand)
        Dim dt As New DataTable()
        da.Fill(dt)
        Dim attachment As String = "attachment; filename=Sheet1.xls"
        Response.ClearContent()
        Response.AddHeader("content-disposition", attachment)
        Response.ContentType = "application/vnd.ms-excel"
        Dim tab As String = ""
        For Each dc As DataColumn In dt.Columns
            Response.Write(tab + dc.ColumnName)
            tab = vbTab
        Next
        Response.Write(vbLf)
        Dim i As Integer
        For Each dr As DataRow In dt.Rows
            tab = ""
            For i = 0 To dt.Columns.Count - 1
                Response.Write(tab & dr(i).ToString())
                tab = vbTab
            Next
            Response.Write(vbLf)
        Next
        Response.[End]()

        'Catch ex As Exception

        'End Try
    End Sub



    Protected Sub Import_Voters_Click(sender As Object, e As EventArgs) Handles Import_Voters.Click

        Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
            If lbxusernme.SelectedIndex > 0 Then
                If controlfileupload.HasFile Then
                    Dim path As String = String.Concat((Server.MapPath("~/csv/" + controlfileupload.FileName)))
                    controlfileupload.PostedFile.SaveAs(path)
                    Dim dt As New DataTable()
                    Dim line As String = Nothing
                    Dim i As Integer = 0
                    Using sr As StreamReader = File.OpenText(path)
                        line = sr.ReadLine()
                        Do While line IsNot Nothing
                            Dim data() As String = line.Split(","c)
                            If data.Length > 0 Then
                                If i = 0 Then
                                    For Each item In data
                                        dt.Columns.Add(New DataColumn())
                                    Next item
                                    i += 1
                                End If
                                Dim row As DataRow = dt.NewRow()
                                row.ItemArray = data
                                dt.Rows.Add(row)
                            End If
                            line = sr.ReadLine()
                        Loop
                    End Using
                    If dt.Rows.Count > 0 Then 'csv file has data
                        'delete old data list 
                        'con.Open()
                        'Dim querydelt As String = "Delete from tblvoters where userId=@userid"
                        'Using cmd1 As New SqlCommand(querydelt, con)
                        '    cmd1.Parameters.AddWithValue("@userid", tbxid.Text)
                        '    cmd1.ExecuteNonQuery()
                        'End Using
                        'con.Close()

                        con.Open()
                        Dim cmd As SqlCommand = con.CreateCommand()
                        Dim cmddlt As SqlCommand = con.CreateCommand()
                        Dim cmddlthd As SqlCommand = con.CreateCommand()
                        Using transaction As SqlTransaction = _
                          con.BeginTransaction()
                            Using bulkCopy As SqlBulkCopy = New SqlBulkCopy(con, SqlBulkCopyOptions.KeepIdentity, transaction)
                                bulkCopy.BatchSize = 10
                                bulkCopy.DestinationTableName = "tblvoters"
                                cmd.Connection = con
                                cmd.Transaction = transaction

                                cmddlt.Transaction = transaction
                                cmddlt.Connection = con

                                cmddlthd.Transaction = transaction
                                cmddlthd.Connection = con

                                Try
                                    'delete old list
                                    cmddlt.CommandText = "Delete from tblvoters where userId=@userid"
                                    cmddlt.Parameters.AddWithValue("@userid", tbxid.Text)
                                    cmddlt.ExecuteNonQuery()


                                    bulkCopy.WriteToServer(dt) 'bulkcopy to database

                                    ''set userid of voters
                                    cmd.CommandText = "UPDATE tblvoters  SET userID = @userid where userid=@null"
                                    cmd.Parameters.AddWithValue("@userid", tbxid.Text)
                                    cmd.Parameters.AddWithValue("@null", 0)
                                    cmd.ExecuteNonQuery()

                                    'delete headears
                                    cmddlthd.CommandText = "Delete from tblvoters where name =@name or indexno=@index or phone=@phone"
                                    cmddlthd.Parameters.AddWithValue("@name", "name")
                                    cmddlthd.Parameters.AddWithValue("@index", "index")
                                    cmddlthd.Parameters.AddWithValue("@phone", "phone")
                                    cmddlthd.ExecuteNonQuery()

                                    transaction.Commit()
                                Catch ex As Exception
                                    transaction.Rollback()
                                Finally
                                    con.Close()
                                End Try
                            End Using
                        End Using

                        'delete all headers 
                        'con.Open()
                        'Dim querydelthd As String = "Delete from tblvoters where name =@name or indexno=@index or phone=@phone"
                        'Using cmd11 As New SqlCommand(querydelthd, con)
                        '    cmd11.Parameters.AddWithValue("@name", "name")
                        '    cmd11.Parameters.AddWithValue("@index", "index")
                        '    cmd11.Parameters.AddWithValue("@phone", "phone")
                        '    cmd11.ExecuteNonQuery()
                        'End Using
                        'con.Close()

                        ClientScript.RegisterStartupScript([GetType](), "alert", "alert('Imported successfully');", True)
                    ElseIf dt.Rows.Count = 0 Then
                        ClientScript.RegisterStartupScript([GetType](), "alert", "alert('Error, csv file has no data');", True)
                    End If

                End If
            Else
                ClientScript.RegisterStartupScript([GetType](), "alert", "alert('Select account');", True)
            End If
        End Using

    End Sub


    Protected Sub Delete_Account_Click(sender As Object, e As EventArgs) Handles Delete_Account.Click
        'Try

        Dim confirmValue As String = Request.Form("confirm_value")
        If confirmValue = "Yes" Then

            Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)

                Dim lbximg As New ListBox
                con1.Open() 'retrieve all images path
                Dim queryimg As String = "SELECT tblcand.image, tblcand.id FROM tblcand INNER JOIN tblpos ON tblcand.postid = tblpos.ID INNER JOIN signups ON tblpos.userid = signups.ID WHERE (signups.username = @usern)"
                Dim myCommandimg As New SqlCommand(queryimg, con1)
                myCommandimg.Parameters.AddWithValue("@usern", tbxusername.Text)
                lbximg.DataSource = myCommandimg.ExecuteReader
                lbximg.DataTextField = "image"
                lbximg.DataValueField = "id"
                lbximg.DataBind()
                con1.Close()

                'loop thru to delete all images
                Do Until lbximg.SelectedIndex = lbximg.Items.Count - 1
                    lbximg.SelectedIndex += 1
                    Dim delpath As String = Server.MapPath("~/databasepics/" & lbximg.SelectedItem.ToString)
                    System.IO.File.Delete(delpath)
                Loop

                'delete from signups
                con1.Open()
                Dim querydelsg As String = "Delete from signups   where username =@usnam"
                Using cmd1 As New SqlCommand(querydelsg, con1)
                    cmd1.Parameters.AddWithValue("@usnam", tbxusername.Text)
                    cmd1.ExecuteNonQuery()
                End Using
                con1.Close()

                ' lbx1.Items.Clear()
                lbxusernme.Items.Clear()
                signupsall()

            End Using
            ScriptManager.RegisterStartupScript(UpdatePanel2, UpdatePanel2.GetType(), "alert", "alert('Account Deleted.');", True)
        Else

        End If
        'Catch ex As Exception

        'End Try
    End Sub
    Protected Sub paswords()
        'lbxpass.SelectedIndex = -1
        Do Until lbxpas.Items.Count = tbxnumber.Text
            Dim maxSize As Integer = 7
            Dim chars As Char() = New Char(61) {}
            chars = "abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNOPQRSTUVWXYZ1234567890".ToCharArray()
            Dim data As Byte() = New Byte(0) {}
            Dim crypto As New RNGCryptoServiceProvider()
            crypto.GetBytes(data)
            data = New Byte(maxSize) {}
            crypto.GetBytes(data)
            Dim result As New StringBuilder(maxSize)
            For Each b As Byte In data
                result.Append(chars(b Mod (chars.Length)))
            Next
            lbxpas.Items.FindByText(result.ToString)

            If lbxpas.SelectedIndex = -1 Then
                lbxpas.Items.Add(result.ToString)
            End If
        Loop
    End Sub



    Protected Sub gen_pas_username()
        Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
            Dim lbx1 As New ListBox
            Dim tbx As New TextBox
            Dim obj As SqlCommand
            obj = con1.CreateCommand

            con1.Open()  'check if account has username and password already 
            Dim myReader As SqlDataReader = Nothing
            Dim pas As New TextBox
            Dim usern1 As String = tbxusername.Text
            Dim querych As String = "select PASWORD from tblvoters where userID= @userid"
            Dim myCommand As New SqlCommand(querych, con1)
            myCommand.Parameters.AddWithValue("@userid", tbxid.Text)
            myReader = myCommand.ExecuteReader()
            While myReader.Read()
                pas.Text = (myReader(0).ToString())
            End While
            con1.Close()


            If pas.Text = "" Then 'has no passwords

                con1.Open()   'select all voters id to listbox
                Dim querysel As String = "select ID, name from tblvoters where userid=@userid"
                Dim myCommandsel As New SqlCommand(querysel, con1)
                myCommandsel.Parameters.AddWithValue("@userid", tbxid.Text)
                lbx1.DataSource = myCommandsel.ExecuteReader
                lbx1.DataTextField = "name"
                lbx1.DataValueField = "id"
                lbx1.DataBind()
                con1.Close()

                tbxnumber.Text = lbx1.Items.Count + 10   ' generate pasword  add extra ten.....no effect
                paswords() 'passord generator function

                Dim id As Integer = 0
                lbx1.SelectedIndex = -1
                Do Until lbx1.SelectedIndex = lbx1.Items.Count - 1
                    lbx1.SelectedIndex += 1
                    'id += 1

                    'set username
                    Dim usenam As String
                    Dim s As String = lbx1.SelectedItem.ToString.Replace("-", " ").Trim
                    Dim p As Integer = s.LastIndexOf(" "c) 'last name only
                    Dim first As String = Mid(s, 1, 1) 'first letter of name

                    usenam = (first & s.Substring(p + 1)).Replace("`", "").Replace(" ", "").Replace("~", "").Replace("!", "") _
            .Replace("@", "").Replace("#", "").Replace("$", "").Replace("%", "").Replace("^", "") _
            .Replace("&", "").Replace("*", "").Replace("(", "").Replace(")", "").Replace("_", "").Replace("-", "").Replace("+", "").Replace("=", "").Replace(";", "") _
            .Replace(":", "").Replace("/", "").Replace("'", "").Replace("?", "").Replace(".", "").Replace(">", "").Replace(",", "") _
            .Replace("<", "").Replace("[", "").Replace("{", "").Replace("}", "").Replace("]", "").Replace("\", "").Replace("|", "").Replace("}", "").Replace("""", "").Trim


                    'update username and password to tblvoters
                    lbxpas.SelectedIndex += 1 'get the password from the password generator listbox
                    Dim pasw As String = lbxpas.SelectedItem.ToString
                    con1.Open()
                    Dim query As String = "UPDATE tblvoters  SET USERNAME = @usename , PASWORD = @pas where id =@id"
                    Using cmd As New SqlCommand(query, con1)
                        cmd.Parameters.AddWithValue("@usename", usenam)
                        cmd.Parameters.AddWithValue("@pas", pasw)
                        cmd.Parameters.AddWithValue("@id", lbx1.SelectedValue.ToString)
                        cmd.ExecuteNonQuery()
                    End Using
                    con1.Close()
                Loop
                ScriptManager.RegisterStartupScript(UpdatePanel2, UpdatePanel2.GetType(), "alert", "alert('Username and password generated Succesfully');", True)
            ElseIf pas.Text <> "" Then
                ScriptManager.RegisterStartupScript(UpdatePanel2, UpdatePanel2.GetType(), "alert", "alert('Username and Password already exist');", True)
            End If
        End Using
    End Sub



    Protected Sub De_authenticate(sender As Object, e As EventArgs) Handles De_authenticate_Account.Click
        Try
            Dim confirmValue As String = Request.Form("confirm_value")
            'Your logic for OK button
            If confirmValue = "Yes" Then
                Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
                    Dim dt As New DataTable()
                    con1.Open()
                    Dim query As String = "UPDATE signups  SET authenticate = @name where code = @nam"
                    Using cmd As New SqlCommand(query, con1)
                        cmd.Parameters.AddWithValue("@name", "NO")
                        cmd.Parameters.AddWithValue("@nam", Mid(lbxusernme.SelectedItem.ToString, 1, 4))
                        cmd.ExecuteNonQuery()
                    End Using
                End Using
                De_authenticate_Account.Enabled = False
                Authenticate_Account.Enabled = True
                ScriptManager.RegisterStartupScript(UpdatePanel2, UpdatePanel2.GetType(), "alert", "alert('Account Deactivated.');", True)
            Else
            End If
        Catch ex As Exception
            ScriptManager.RegisterStartupScript(UpdatePanel2, UpdatePanel2.GetType(), "alert", "alert('ERROR Deactivating account.');", True)
        End Try

    End Sub


    Protected Sub Confirmactivation(sender As Object, e As EventArgs) Handles Authenticate_Account.Click
        Try
            Dim confirmValue As String = Request.Form("confirm_value")
            'Your logic for OK button
            If confirmValue = "Yes" Then
                'set authenticate to YES
                Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
                    Dim dt As New DataTable()
                    con1.Open()
                    Dim query As String = "UPDATE signups  SET authenticate = @name    where code = @nam"
                    Using cmd As New SqlCommand(query, con1)
                        cmd.Parameters.AddWithValue("@name", "YES")
                        cmd.Parameters.AddWithValue("@nam", Mid(lbxusernme.SelectedItem.ToString, 1, 4))
                        cmd.ExecuteNonQuery()
                    End Using
                    con1.Close()
                    De_authenticate_Account.Enabled = True
                    Authenticate_Account.Enabled = False

                    'advertise bulksms/email 
                    Dim read As SqlDataReader
                    Dim lbxadv As New ListBox
                    Dim lbxadv1 As New ListBox
                    con1.Open()   'select all voters id to listbox
                    Dim querysel As String = "select tblcand.name, tblcand.phone, tblpos.position, tblcand.refno from tblcand INNER JOIN tblpos ON tblcand.postid = tblpos.ID INNER JOIN signups ON signups.ID = tblpos.userid AND tblcand.postid = tblpos.ID WHERE (signups.ID = @id)"
                    Dim myCommandsel As New SqlCommand(querysel, con1)
                    myCommandsel.Parameters.AddWithValue("@id", tbxid.Text)
                    read = myCommandsel.ExecuteReader()
                    lbxadv.DataSource = read
                    lbxadv.DataTextField = "name"
                    lbxadv.DataValueField = "phone"
                    lbxadv.DataBind()
                    read.Close()

                    read = myCommandsel.ExecuteReader()
                    lbxadv1.DataSource = read
                    lbxadv1.DataTextField = "position"
                    lbxadv1.DataValueField = "refno"
                    lbxadv1.DataBind()
                    read.Close()
                    con1.Close()

                    'loop to send sms
                    lbxadv.SelectedIndex = -1
                    lbxadv1.SelectedIndex = -1
                    Dim mailto
                    Dim body
                    Dim bod
                    Do Until lbxadv.SelectedIndex = lbxadv.Items.Count - 1
                        lbxadv.SelectedIndex += 1
                        lbxadv1.SelectedIndex += 1
                        mailto = lbxadv.SelectedValue.ToString
                        mailto = mailto.ToString.Substring(mailto.ToString.Length - 9, 9)
                        mailto = "233" & mailto
                        body = "Congrats " + lbxadv.SelectedItem.ToString + ", You are successfully added as an aspirant for " + lbxadv1.SelectedItem.ToString + " in " + Tbxbalotname.Text + ". Your candidate Reference No. is " + lbxadv1.SelectedValue.ToString + ""
                        bod = " Send Campaign message via sms and email (with pdf attachment) to voters with evotegh.com bulk messaging services. visit www.evotegh.com/services"
                        'sms quick API 
                        Dim url As String = "https://api.smsgh.com/v3/messages/send?" + "From=Evotegh&To=%2B" + mailto + "" + "&Content=" + body & bod + "" + "&ClientId=vfwdjpjt" + "&ClientSecret=lysnrxhf" + "&RegisteredDelivery=true"
                        Dim client As New WebClient()
                        Dim text As String = client.DownloadString(url)

                        'body = bod
                        ''sms quick API advertize bulk sms
                        'url = "https://api.smsgh.com/v3/messages/send?" + "From=Evotegh&To=%2B" + mailto + "" + "&Content=" + body + "" + "&ClientId=vfwdjpjt" + "&ClientSecret=lysnrxhf" + "&RegisteredDelivery=true"
                        'text = client.DownloadString(url)
                    Loop

                End Using
                ScriptManager.RegisterStartupScript(UpdatePanel2, UpdatePanel2.GetType(), "alert", "alert('Account Activated.');", True)
            End If

        Catch ex As Exception
            ScriptManager.RegisterStartupScript(UpdatePanel2, UpdatePanel2.GetType(), "alert", "alert('ERROR, check acount info.');", True)
        End Try
    End Sub


    Protected Sub btnaccount_Click(sender As Object, e As EventArgs) Handles btnaccount.Click

        MultiView1.ActiveViewIndex = 0

        btnaccount.BorderStyle = BorderStyle.None
        btnactivate.BorderStyle = BorderStyle.NotSet
        btnvoters.BorderStyle = BorderStyle.NotSet
        btnmail.BorderStyle = BorderStyle.NotSet
        btnbulksms.BorderStyle = BorderStyle.NotSet

        btnaccount.Style.Add("background-color", "#CCCCCC")
        btnactivate.Style.Add("background-color", "Silver")
        btnvoters.Style.Add("background-color", "Silver")
        btnvoters.Style.Add("background-color", "Silver")
        btnbulksms.Style.Add("background-color", "Silver")

        lbxusernme_SelectedIndexChanged(lbxusernme, Nothing)


    End Sub

    Protected Sub btnactivate_Click(sender As Object, e As EventArgs) Handles btnactivate.Click

        MultiView1.ActiveViewIndex = 1
        btnaccount.BorderStyle = BorderStyle.NotSet
        btnactivate.BorderStyle = BorderStyle.None
        btnvoters.BorderStyle = BorderStyle.NotSet
        btnmail.BorderStyle = BorderStyle.NotSet
        btnbulksms.BorderStyle = BorderStyle.NotSet

        btnaccount.Style.Add("background-color", "Silver")
        btnactivate.Style.Add("background-color", "#CCCCCC")
        btnvoters.Style.Add("background-color", "Silver")
        btnmail.Style.Add("background-color", "Silver")
        btnbulksms.Style.Add("background-color", "Silver")


        If tbxAuthenticate.Text.Trim = "YES" Then
            Authenticate_Account.Enabled = False
            De_authenticate_Account.Enabled = True
        ElseIf tbxAuthenticate.Text.Trim = "NO" Then
            Authenticate_Account.Enabled = True
            De_authenticate_Account.Enabled = False
        End If
    End Sub

    Protected Sub btnmail_Click(sender As Object, e As EventArgs) Handles btnmail.Click


        MultiView1.ActiveViewIndex = 2

        btnbulksms.BorderStyle = BorderStyle.NotSet
        btnaccount.BorderStyle = BorderStyle.NotSet
        btnactivate.BorderStyle = BorderStyle.NotSet
        btnvoters.BorderStyle = BorderStyle.NotSet
        btnmail.BorderStyle = BorderStyle.None

        btnbulksms.Style.Add("background-color", "Silver")
        btnaccount.Style.Add("background-color", "Silver")
        btnactivate.Style.Add("background-color", "Silver")
        btnvoters.Style.Add("background-color", "Silver")
        btnmail.Style.Add("background-color", "#CCCCCC")

        lbxmail.Items.Clear()
        lbxsms.Items.Clear()

        Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
            Dim lbxma As New ListBox
            Dim lbxsm As New ListBox
            Dim obj As SqlCommand
            obj = con1.CreateCommand

            con1.Open()
            Dim querym As String = "select * from signups where mailsent=@mail and authenticate=@auth "
            Dim myCommandm As New SqlCommand(querym, con1)
            myCommandm.Parameters.AddWithValue("@auth", "YES")
            myCommandm.Parameters.AddWithValue("@mail", "NO")


            lbxma.DataSource = myCommandm.ExecuteReader
            lbxma.DataTextField = "schoolname"
            lbxma.DataValueField = "title"
            lbxma.DataBind()
            con1.Close()


            con1.Open()
            Dim querysms As String = "select * from signups where smssent=@sms and authenticate=@auth "
            Dim myCommandsms As New SqlCommand(querysms, con1)
            myCommandsms.Parameters.AddWithValue("@auth", "YES")
            myCommandsms.Parameters.AddWithValue("@sms", "NO")


            lbxsm.DataSource = myCommandm.ExecuteReader
            lbxsm.DataTextField = "schoolname"
            lbxsm.DataValueField = "title"
            lbxsm.DataBind()
            con1.Close()

            Do Until lbxma.SelectedIndex = lbxma.Items.Count - 1
                lbxma.SelectedIndex += 1
                lbxmail.Items.Add(lbxma.SelectedItem.ToString & "-" & lbxma.SelectedValue.ToString)
            Loop


            Do Until lbxsm.SelectedIndex = lbxsm.Items.Count - 1
                lbxsm.SelectedIndex += 1
                lbxsms.Items.Add(lbxsm.SelectedItem.ToString & "-" & lbxsm.SelectedValue.ToString)
            Loop
        End Using



    End Sub

    Protected Sub btnvoters_Click(sender As Object, e As EventArgs) Handles btnvoters.Click
        MultiView1.ActiveViewIndex = 3

        btnbulksms.BorderStyle = BorderStyle.NotSet
        btnaccount.BorderStyle = BorderStyle.NotSet
        btnactivate.BorderStyle = BorderStyle.NotSet
        btnvoters.BorderStyle = BorderStyle.None
        btnmail.BorderStyle = BorderStyle.NotSet

        btnaccount.Style.Add("background-color", "Silver")
        btnactivate.Style.Add("background-color", "Silver")
        btnvoters.Style.Add("background-color", "#CCCCCC")
        btnmail.Style.Add("background-color", "Silver")
        btnbulksms.Style.Add("background-color", "Silver")
    End Sub

    Protected Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged
        signupsall()
        lbxusernme_SelectedIndexChanged(lbxusernme, Nothing)
    End Sub

    Protected Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton2.CheckedChanged
        expiredaccount()
        lbxusernme_SelectedIndexChanged(lbxusernme, Nothing)
    End Sub

    Protected Sub RadioButton3_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton3.CheckedChanged
        Signupauthenticated()
        lbxusernme_SelectedIndexChanged(lbxusernme, Nothing)
    End Sub

    Protected Sub RadioButton4_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton4.CheckedChanged
        Un_signupauthenticated()
        lbxusernme_SelectedIndexChanged(lbxusernme, Nothing)
    End Sub

    Protected Sub sendsms(sender As Object, e As EventArgs) Handles tbxsms.Click
        Try
            Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
                Dim lbx1 As New ListBox
                Dim lbx2 As New ListBox
                Dim lbx3 As New ListBox
                Dim tbx As New TextBox
                Dim obj As SqlCommand
                obj = con1.CreateCommand

                con1.Open()   'select all to listbox
                Dim usern As String = tbxid.Text
                Dim read As SqlDataReader
                Dim cmd As SqlCommand = New SqlCommand("getvotersms", con1)
                cmd.Connection = con1
                cmd.CommandText = "getvotersms"
                cmd.CommandType = CommandType.StoredProcedure

                cmd.Parameters.AddWithValue("@user", usern)
                read = cmd.ExecuteReader
                lbx1.DataSource = read
                lbx1.DataTextField = "phone"
                lbx1.DataValueField = "username"
                lbx1.DataBind()
                read.Close()

                read = cmd.ExecuteReader
                lbx2.DataSource = read
                lbx2.DataTextField = "name"
                lbx2.DataValueField = "pasword"
                lbx2.DataBind()
                read.Close()

                read = cmd.ExecuteReader
                lbx3.DataSource = read
                lbx3.DataTextField = "id"
                lbx3.DataValueField = "id"
                lbx3.DataBind()
                read.Close()
                con1.Close()


                lbx1.SelectedIndex = -1
                lbx2.SelectedIndex = -1
                lbx3.SelectedIndex = -1

                Dim MailTo
                Dim errorcount As Integer = 0
                Dim success As Integer = 0
                Do Until lbx1.SelectedIndex = lbx1.Items.Count - 1

                    Try

                        lbx1.SelectedIndex += 1
                        lbx2.SelectedIndex += 1
                        lbx3.SelectedIndex += 1
                        Dim phon As String = (lbx1.SelectedItem.ToString).Replace(" ", "")
                        'phon.Replace("+", "0")
                        If phon.ToString.Length = 10 Then
                            phon = "+233" & phon.ToString.Substring(phon.ToString.Length - 9, 9)
                        End If

                        MailTo = phon
                        Dim p As String = lbx2.SelectedItem.ToString 'name 
                        Dim hello = "Hello " + p + ": "
                        Dim bodi = "Your evotegh Username: " + lbx1.SelectedValue.ToString + " and password: " & lbx2.SelectedValue.ToString
                        Dim duration = " Please vote at evotegh.somee.com on " + tbxstarttime.Text + " to " + tbxEndTime.Text + ""
                        Dim content = hello & bodi & duration

                        If MailTo <> "" Then 'has phone number
                            'sms quick API
                            ' Dim url As String = "https://api.smsgh.com/v3/messages/send?" + "From=Evotegh&To=%2B" + MailTo + "" + "&Content=" + content + "" + "&ClientId=vfwdjpjt" + "&ClientSecret=lysnrxhf" + "&RegisteredDelivery=true"
                            Dim url As String = "https://api.smsgh.com/v3/messages/send?" + "From=Evotegh&To=%2B" + MailTo + "" + "&Content=" + content + "" + "&ClientId=irewgcsc" + "&ClientSecret=yznceuup" + "&RegisteredDelivery=true"

                            Dim client As New WebClient()
                            Dim text As String = client.DownloadString(url)



                            '"&ClientId=irewgcsc" + "&ClientSecret=yznceuup" + "&RegisteredDelivery=true"

                            'update sms
                            con1.Open()
                            Dim cmdupd As SqlCommand = New SqlCommand("updatesms", con1)
                            cmdupd.Connection = con1
                            cmdupd.CommandText = "updatesms"
                            cmdupd.CommandType = CommandType.StoredProcedure
                            cmdupd.Parameters.AddWithValue("id", lbx3.SelectedItem.ToString)
                            cmdupd.ExecuteNonQuery()
                            con1.Close()

                            'successful sms counter
                            success += 1

                        ElseIf MailTo = "" Then
                            'continue loop
                        End If

                    Catch ex As Exception
                        'error counter, count errors and continue loop
                        errorcount += 1
                    End Try
                Loop
                ClientScript.RegisterStartupScript([GetType](), "alert", "alert('" + success.ToString + " SMS Sent Successfully, " + errorcount.ToString + " Errors occured');", True)
            End Using

        Catch ex As Exception
            ClientScript.RegisterStartupScript([GetType](), "alert", "alert('ERROR, sending email');", True)
        End Try

    End Sub
    'Private Sub smscand()
    '    Dim url As String = "https://api.smsgh.com/v3/messages/send?" + "From=Evotegh&To=%2B233203712650" + "&Content=Code%2C+" + tsms.Text + "" + "&ClientId=vfwdjpjt" + "&ClientSecret=lysnrxhf" + "&RegisteredDelivery=true"
    '    Dim client As New WebClient()
    '    Dim text As String = client.DownloadString(url)
    '    'Console.WriteLine(text)
    '    'Console.ReadKey()
    'End Sub

    Protected Sub sendemail()
        If ckbxmail.Checked = True Then
            Try
                Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
                    Dim lbx1 As New ListBox
                    Dim lbx2 As New ListBox
                    Dim lbx3 As New ListBox
                    Dim tbx As New TextBox
                    Dim obj As SqlCommand
                    obj = con1.CreateCommand


                    con1.Open()   'select all to listbox
                    Dim usern As String = tbxid.Text
                    Dim read As SqlDataReader
                    Dim cmd As SqlCommand = New SqlCommand("getvotermail", con1)
                    cmd.Connection = con1
                    cmd.CommandText = "getvotermail"
                    cmd.CommandType = CommandType.StoredProcedure

                    cmd.Parameters.AddWithValue("@user", usern)
                    read = cmd.ExecuteReader
                    lbx1.DataSource = read
                    lbx1.DataTextField = "email"
                    lbx1.DataValueField = "username"
                    lbx1.DataBind()
                    read.Close()


                    read = cmd.ExecuteReader
                    lbx2.DataSource = read
                    lbx2.DataTextField = "name"
                    lbx2.DataValueField = "pasword"
                    lbx2.DataBind()
                    read.Close()

                    read = cmd.ExecuteReader
                    lbx3.DataSource = read
                    lbx3.DataTextField = "id"
                    lbx3.DataValueField = "id"
                    lbx3.DataBind()
                    read.Close()
                    con1.Close()

                    lbx1.SelectedIndex = -1
                    lbx2.SelectedIndex = -1
                    lbx3.SelectedIndex = -1
                    Dim MailTo
                    Dim MailFrom
                    Dim errorcount As Integer = 0
                    Dim success As Integer = 0
                    MailFrom = "info@evotegh.com"
                    Do Until lbx1.SelectedIndex = lbx1.Items.Count - 1
                        Try
                        lbx1.SelectedIndex += 1
                        lbx2.SelectedIndex += 1
                        lbx3.SelectedIndex += 1
                        MailTo = lbx1.SelectedItem.ToString
                        If MailTo <> "" Then
                            Dim hello = "Hello " + lbx2.SelectedItem.ToString + ": " + ControlChars.NewLine + ""
                            Dim bodi = "Your evotegh Username: " + lbx1.SelectedValue.ToString + " and password: " & lbx2.SelectedValue.ToString
                            Dim duration = "Please vote at evotegh.com on " + tbxstarttime.Text + " to " + tbxEndTime.Text + ""
                            Dim objMail As New System.Web.Mail.MailMessage()
                            objMail.From = MailFrom
                            objMail.To = MailTo
                            objMail.Subject = "Evotegh authentication"
                            objMail.BodyFormat = MailFormat.Html 'MailFormat.Text to send plain text email
                            objMail.Priority = System.Net.Mail.MailPriority.High
                            objMail.Body = hello & bodi & ControlChars.NewLine & duration
                            System.Web.Mail.SmtpMail.SmtpServer = "relay-hosting.secureserver.net"
                            System.Web.Mail.SmtpMail.Send(objMail)
                            objMail = Nothing

                            'update email
                            con1.Open()
                            Dim cmdupd As SqlCommand = New SqlCommand("updateemail", con1)
                            cmdupd.Connection = con1
                            cmdupd.CommandText = "updateemail"
                            cmdupd.CommandType = CommandType.StoredProcedure
                            cmdupd.Parameters.AddWithValue("@id", lbx3.SelectedItem.ToString)
                            cmdupd.ExecuteNonQuery()
                                con1.Close()

                                'successful email counter
                                success += 1
                        ElseIf MailTo = "" Then
                            'continue loop
                            End If

                        Catch ex As Exception
                            'error email counter
                            errorcount += 1
                        End Try
                    Loop
                    ClientScript.RegisterStartupScript([GetType](), "alert", "alert('" + success.ToString + " Emails Sent Successfully, " + errorcount.ToString + " Errors occured');", True)

                End Using
            Catch ex As Exception
                ClientScript.RegisterStartupScript([GetType](), "alert", "alert('ERROR, sending email');", True)
            End Try
        End If
    End Sub

    Protected Sub btngenertepas(sender As Object, e As EventArgs) Handles btngenpas.Click
        'assign username and password
        gen_pas_username()
    End Sub

    

    Protected Sub sendsmsreminder(sender As Object, e As EventArgs) Handles btnsmsreminder.Click
        Try
            Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
                'retrieve id of voters to send sms reminder from tblvoters
                Dim smsstat As String = "NO"
                Dim lbxsmsid As New ListBox
                con1.Open()
                Dim querysmsid As String = "select ID from tblvoters where userID=@userid and smsreminder=@smsreminder"
                Dim cmdsmsid As New SqlCommand(querysmsid, con1)
                cmdsmsid.Parameters.AddWithValue("@userid", tbxid.Text)
                cmdsmsid.Parameters.AddWithValue("@smsreminder", smsstat)
                Dim drsmsid As DbDataReader = cmdsmsid.ExecuteReader()
                lbxsmsid.DataSource = drsmsid
                lbxsmsid.DataTextField = "ID"
                lbxsmsid.DataValueField = "ID"
                lbxsmsid.DataBind()
                con1.Close()

                'loop and send sms
                lbxsmsid.SelectedIndex = -1
                Do Until lbxsmsid.SelectedIndex = lbxsmsid.Items.Count - 1
                    lbxsmsid.SelectedIndex += 1
                    'select voter info from table
                    Dim name As New TextBox
                    Dim username As New TextBox
                    Dim password As New TextBox
                    Dim phone As New TextBox

                    con1.Open()
                    Dim querysms As String = "select name, phone from tblvoters where ID=@id"
                    Dim cmdsms As New SqlCommand(querysms, con1)
                    cmdsms.Parameters.AddWithValue("@id", lbxsmsid.SelectedValue.ToString)
                    Dim drsms As DbDataReader = cmdsms.ExecuteReader()
                    While drsms.Read
                        name.Text = drsms(0).ToString
                        phone.Text = drsms(1).ToString
                    End While
                    con1.Close()
                    Dim p As String = name.Text


                    'phone.Text = phone.Text.Substring(phone.Text.Length - 9, 9)
                    'phone.Text = "233" & phone.Text

                    phone.Text = phone.Text.Replace(" ", "")
                    phone.Text.Replace("+", "00")
                    If phone.Text.ToString.Length = 10 Then
                        phone.Text = "00233" & phone.ToString.Substring(phone.ToString.Length - 9, 9)
                    End If

                    'send sms
                    Dim content As String = "Hi " + p + ", Please be reminded to vote in the ongoing" + Tbxbalotname.Text + " at www.evotegh.somee.com. Voting started at " + tbxstarttime.Text + " and ends at " + tbxEndTime.Text + ""
                    'sms api
                    Dim url As String = "https://api.smsgh.com/v3/messages/send?" + "From=Evotegh&To=%2B" + phone.Text + "" + "&Content=" + content + "" + "&ClientId=vfwdjpjt" + "&ClientSecret=lysnrxhf" + "&RegisteredDelivery=true"
                    Dim client As New WebClient()
                    Dim text As String = client.DownloadString(url)

                    'set smsreminder flag (smsstatus) to YES
                    con1.Open()
                    Dim stat As String = "YES"
                    Dim queryfg As String = "UPDATE tblvoters  SET smsreminder=@status where id =@id"
                    Using cmdfg As New SqlCommand(queryfg, con1)
                        cmdfg.Parameters.AddWithValue("@status", stat)
                        cmdfg.Parameters.AddWithValue("@id", lbxsmsid.SelectedValue.ToString)
                        cmdfg.ExecuteNonQuery()
                    End Using
                    con1.Close()
                Loop
                ClientScript.RegisterStartupScript(Me.GetType, "alert", "alert('SMS sent successfully.');", True)
            End Using

        Catch ex As Exception
            ClientScript.RegisterStartupScript(Me.GetType, "alert", "alert('SMS sending error');", True)
        End Try

    End Sub

    Protected Sub btnbulksms_Click(sender As Object, e As EventArgs) Handles btnbulksms.Click

        Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
            con1.Open() 'select requested accounts
            Dim query As String = " SELECT DISTINCT tblsmsrequest.code, signups.schoolname as name FROM tblsmsrequest INNER JOIN tblcand ON tblsmsrequest.candid = tblcand.ID INNER JOIN tblpos ON tblcand.postid = tblpos.ID INNER JOIN signups ON tblpos.userid = signups.ID "
            Dim myCommand As New SqlCommand(query, con1)
            lbxbulkaccounts.DataSource = myCommand.ExecuteReader
            lbxbulkaccounts.DataTextField = "name"
            lbxbulkaccounts.DataValueField = "code"
            lbxbulkaccounts.DataBind()
            con1.Close()
        End Using

        MultiView1.ActiveViewIndex = 4
        btnbulksms.BorderStyle = BorderStyle.None
        btnaccount.BorderStyle = BorderStyle.NotSet
        btnactivate.BorderStyle = BorderStyle.NotSet
        btnvoters.BorderStyle = BorderStyle.NotSet
        btnmail.BorderStyle = BorderStyle.NotSet

        btnbulksms.Style.Add("background-color", "#CCCCCC")
        btnaccount.Style.Add("background-color", "Silver")
        btnactivate.Style.Add("background-color", "Silver")
        btnvoters.Style.Add("background-color", "Silver")
        btnvoters.Style.Add("background-color", "Silver")

        lbxbulkcandnotsent.Items.Clear()
        lbxbulkcandsent.Items.Clear()

        Tbxreqdate.Text = ""
        tbxnumbermails.Text = ""
        tbxsentdat.Text = ""
        tbxcost.Text = ""

    End Sub

    Protected Sub lbxbulkcandsent_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lbxbulkcandsent.SelectedIndexChanged
        Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
            con1.Open()
            Dim query As String = " SELECT requestdate, sentdate, number, message from tblsmsrequest where id =@id"
            Dim myCommand As New SqlCommand(query, con1)
            myCommand.Parameters.AddWithValue("@id", lbxbulkcandsent.SelectedValue.ToString)
            Dim reader As DbDataReader = myCommand.ExecuteReader
            While reader.Read
                Tbxreqdate.Text = reader(0).ToString
                tbxsentdat.Text = reader(1).ToString
                tbxnumbermails.Text = reader(2).ToString
                tbxmessage.Text = reader(3).ToString
            End While
            con1.Close()

            If tbxnumbermails.Text = "All" Then
                con1.Open()
                Dim queryal As String = " SELECT Count(id) as ids from tblvoters where userid =(select id from signups where code=@code)"
                Dim myCommandal As New SqlCommand(queryal, con1)
                myCommandal.Parameters.AddWithValue("@code", lbxbulkaccounts.SelectedValue.ToString)
                Dim readeral As DbDataReader = myCommandal.ExecuteReader
                While readeral.Read
                    tbxnumbermails.Text = readeral(0).ToString
                End While
                con1.Close()
            End If
            tbxcost.Text = 0.06 * tbxnumbermails.Text
            lblsmshead.Text = lbxbulkcandsent.SelectedItem.ToString
        End Using
        Cbxbulkmail.Checked = False
    End Sub

    Protected Sub lbxbulkaccounts_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lbxbulkaccounts.SelectedIndexChanged
        Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
            con1.Open()
            Dim query As String = " SELECT tblsmsrequest.id, tblcand.name FROM tblsmsrequest INNER JOIN tblcand ON tblsmsrequest.candid = tblcand.ID WHERE tblsmsrequest.code = @code and sentflag=@sent"
            Dim myCommand As New SqlCommand(query, con1)
            myCommand.Parameters.AddWithValue("@code", lbxbulkaccounts.SelectedValue.ToString)
            myCommand.Parameters.AddWithValue("@sent", "YES")
            lbxbulkcandsent.DataSource = myCommand.ExecuteReader
            lbxbulkcandsent.DataTextField = "name"
            lbxbulkcandsent.DataValueField = "id"
            lbxbulkcandsent.DataBind()
            con1.Close()

            con1.Open()
            Dim NO = "NO"
            Dim queryno As String = " SELECT tblsmsrequest.id, tblcand.name FROM tblsmsrequest INNER JOIN tblcand ON tblsmsrequest.candid = tblcand.ID WHERE tblsmsrequest.code = @code and sentflag=@sent"
            Dim myCommandno As New SqlCommand(queryno, con1)
            myCommandno.Parameters.AddWithValue("@code", lbxbulkaccounts.SelectedValue.ToString)
            myCommandno.Parameters.AddWithValue("@sent", NO)
            lbxbulkcandnotsent.DataSource = myCommandno.ExecuteReader
            lbxbulkcandnotsent.DataTextField = "name"
            lbxbulkcandnotsent.DataValueField = "id"
            lbxbulkcandnotsent.DataBind()
            con1.Close()
        End Using

    End Sub

    Protected Sub lbxbulkcandnotsent_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lbxbulkcandnotsent.SelectedIndexChanged
        Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
            Dim Reader As SqlDataReader = Nothing
            con1.Open()
            Dim que As String = " SELECT requestdate, sentdate, number, message, lastindex from tblsmsrequest where id =@id"
            Dim myCommands As New SqlCommand(que, con1)
            myCommands.Parameters.AddWithValue("@id", lbxbulkcandnotsent.SelectedValue.ToString)
            reader = myCommands.ExecuteReader
            While reader.Read
                Tbxreqdate.Text = Reader(0).ToString
                tbxnumbermails.Text = Reader(2).ToString
                tbxmessage.Text = Reader(3).ToString
                tbxlastindex.Text = Reader(4).ToString
            End While
            tbxsentdat.Text = "Not Sent"
            con1.Close()
            
            If tbxnumbermails.Text = "All" Then
                con1.Open()
                Dim queryal As String = " SELECT Count(id) as ids from tblvoters where userid =(select id from signups where code=@code)"
                Dim myCommandal As New SqlCommand(queryal, con1)
                Dim Readeral As SqlDataReader = Nothing
                myCommandal.Parameters.AddWithValue("@code", lbxbulkaccounts.SelectedValue.ToString)
                Readeral = myCommandal.ExecuteReader
                While Readeral.Read
                    tbxnumbermails.Text = Readeral(0).ToString
                End While
                con1.Close()
            End If
            tbxcost.Text = 0.06 * tbxnumbermails.Text
            lblsmshead.Text = lbxbulkcandnotsent.SelectedItem.ToString
            Cbxbulkmail.Checked = False
        End Using
    End Sub


    Protected Sub bulkcampsms()
        Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)

            'get all voters phone and email
            Dim lbxsms As New ListBox
            con1.Open()
            Dim query As String = "Select id, phone from tblvoters where userid=(select id from signups where code=@code)"
            Dim myCommand As New SqlCommand(query, con1)
            myCommand.Parameters.AddWithValue("@code", lbxbulkaccounts.SelectedValue.ToString)
            lbxsms.DataSource = myCommand.ExecuteReader
            lbxsms.DataTextField = "phone"
            lbxsms.DataValueField = "id"
            lbxsms.DataBind()
            myCommand.ExecuteReader.Close()


        End Using
    End Sub



    Protected Sub bulkmail()
        Try

       
        If tbxnumbermails.Text <> "" Then
            'get all voters phone and email
            Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
                Dim lbxsms As New ListBox
                Dim lbxemail As New ListBox
                con1.Open() 'select requested accounts
                Dim query As String = "Select id, phone, email from tblvoters where userid=(select id from signups where code=@code)"
                Dim myCommand As New SqlCommand(query, con1)
                myCommand.Parameters.AddWithValue("@code", lbxbulkaccounts.SelectedValue.ToString)
                lbxsms.DataSource = myCommand.ExecuteReader
                lbxsms.DataTextField = "phone"
                lbxsms.DataValueField = "id"
                lbxsms.DataBind()
                myCommand.ExecuteReader.Close()

                lbxemail.DataSource = myCommand.ExecuteReader
                lbxemail.DataTextField = "email"
                lbxemail.DataValueField = "id"
                lbxemail.DataBind()
                myCommand.ExecuteReader.Close()
                con1.Close()


                Dim i As Integer = lbxsms.Items.Count
                If i > 0 Then 'has voters
                        lbxsms.SelectedIndex = tbxlastindex.text
                        lbxemail.SelectedIndex = tbxlastindex.text
                    Do Until lbxsms.SelectedIndex = lbxsms.Items.Count - 1
                        lbxsms.SelectedIndex += 1
                        lbxemail.SelectedIndex += 1
                        'send sms
                        Dim url As String = "https://api.smsgh.com/v3/messages/send?" + "From=" + lbxbulkcandnotsent.SelectedItem.ToString + "&To=%2B" + lbxsms.SelectedItem.ToString + "" + "&Content=" + tbxmessage.Text + "" + "&ClientId=vfwdjpjt" + "&ClientSecret=lysnrxhf" + "&RegisteredDelivery=true"
                        Dim client As New WebClient()
                        Dim text As String = client.DownloadString(url)


                        'send email
                        Dim objMail As New System.Web.Mail.MailMessage()
                        objMail.From = "info@evotegh.com"
                        objMail.To = lbxemail.SelectedItem.ToString
                            objMail.Subject = lbxbulkcandnotsent.SelectedItem.ToString
                        objMail.BodyFormat = MailFormat.Html 'MailFormat.Text to send plain text email
                        objMail.Priority = System.Net.Mail.MailPriority.High
                        objMail.Body = tbxmessage.Text
                        System.Web.Mail.SmtpMail.SmtpServer = "relay-hosting.secureserver.net"
                        System.Web.Mail.SmtpMail.Send(objMail)
                        objMail = Nothing

                            'update last voter index sent
                            con1.Open()
                            Dim queryfg As String = "UPDATE tblsmsrequest  SET lastindex=@last where id =@id"
                            Using cmdfg As New SqlCommand(queryfg, con1)
                                cmdfg.Parameters.AddWithValue("@last", lbxsms.SelectedIndex.ToString)
                                cmdfg.Parameters.AddWithValue("@id", lbxbulkcandnotsent.SelectedValue.ToString)
                                cmdfg.ExecuteNonQuery()
                            End Using
                            con1.Close()
                        Loop
                        'update sent flag to yes
                        con1.Open()
                        Dim queryst As String = "UPDATE tblsmsrequest  SET sentflag=@sent where id =@id"
                        Using cmdst As New SqlCommand(queryst, con1)
                            cmdst.Parameters.AddWithValue("@sent", "YES")
                            cmdst.Parameters.AddWithValue("@id", lbxbulkcandnotsent.SelectedValue.ToString)
                            cmdst.ExecuteNonQuery()
                        End Using
                        con1.Close()

                        Cbxbulkmail.Checked = False
                    ClientScript.RegisterStartupScript(Me.GetType, "alert", "alert('SMS/Email sending completed successfully');", True)
                End If
            End Using
            End If

        Catch ex As Exception
            ClientScript.RegisterStartupScript(Me.GetType, "alert", "alert('SMS/Email sending Error');", True)

        End Try
    End Sub

    

  

   
End Class