﻿Imports System.Data.SqlClient

Public Class _default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            '    vtlist.Style.Add("display", "none")
            'ElseIf IsPostBack Then
            '    If Lbldidplay.Text = "1" Then
            '        vtlist.Style.Add("display", "block")
            '        Lbldidplay.Text = "0"
            '    End If
        End If
    End Sub

    Protected Sub btnvote_view2_Click(sender As Object, e As EventArgs) Handles btnvote.Click
        Try
            tbxlogusername.Text = tbxlogusername.Text.Replace("`", "").Replace("~", "").Replace("!", "") _
            .Replace("@", "").Replace("#", "").Replace("$", "").Replace("%", "").Replace("^", "") _
            .Replace("&", "").Replace("*", "").Replace("(", "").Replace(")", "").Replace("+", "").Replace("=", "").Replace(";", "") _
            .Replace(":", "").Replace("/", "").Replace("'", "").Replace("?", "").Replace(".", "").Replace(">", "").Replace(",", "") _
            .Replace("<", "").Replace("[", "").Replace("{", "").Replace("}", "").Replace("]", "").Replace("\", "").Replace("|", "").Replace("}", "").Replace("""", "").Trim

            tbxlogpassword.Text = tbxlogpassword.Text.Replace("`", "").Replace("~", "").Replace("!", "") _
           .Replace("@", "").Replace("#", "").Replace("$", "").Replace("%", "").Replace("^", "") _
           .Replace("&", "").Replace("*", "").Replace("(", "").Replace(")", "").Replace("_", "").Replace("-", "").Replace("+", "").Replace("=", "").Replace(";", "") _
           .Replace(":", "").Replace("/", "").Replace("'", "").Replace("?", "").Replace(".", "").Replace(">", "").Replace(",", "") _
           .Replace("<", "").Replace("[", "").Replace("{", "").Replace("}", "").Replace("]", "").Replace("\", "").Replace("|", "").Replace("}", "").Replace("""", "").Trim

            Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
                Dim dt As New DataTable()
                Dim myReader As SqlDataReader = Nothing
                Dim myReader1 As SqlDataReader = Nothing
                con1.Open()
                Dim starttime As New TextBox
                Dim endtime As New TextBox
                Dim auth As New TextBox
                Dim voterid As New TextBox
                Dim title As New TextBox
                Dim userid As New TextBox
                Dim votestatus As New TextBox
                Dim votername As New TextBox

                Dim cmdvt As SqlCommand = New SqlCommand("voteid", con1)
                cmdvt.Connection = con1
                cmdvt.CommandText = "voteid"
                cmdvt.CommandType = CommandType.StoredProcedure
                cmdvt.Parameters.AddWithValue("@voterusername", tbxlogusername.Text)
                cmdvt.Parameters.AddWithValue("@voterpassword", tbxlogpassword.Text)
                Dim sqlReadervt As SqlDataReader = cmdvt.ExecuteReader()
                While sqlReadervt.Read
                    userid.Text = sqlReadervt(0).ToString
                    votestatus.Text = sqlReadervt(1).ToString
                    votername.Text = sqlReadervt(2).ToString
                    voterid.Text = sqlReadervt(3).ToString
                End While
                sqlReadervt.Close()

                Dim lbxvt As New ListBox
                Dim sqlReadervt1 As SqlDataReader = cmdvt.ExecuteReader()
                lbxvt.DataSource = sqlReadervt1
                lbxvt.DataTextField = "userid"
                lbxvt.DataValueField = "ID"
                lbxvt.DataBind()
                sqlReadervt.Close()
                con1.Close()
                If lbxvt.Items.Count = 1 Then
                    con1.Open()
                    Dim cmd As SqlCommand = New SqlCommand("votelogin", con1)
                    cmd.Connection = con1
                    cmd.CommandText = "votelogin"
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Parameters.AddWithValue("@userid", userid.Text)
                    Dim sqlReader As SqlDataReader = cmd.ExecuteReader()
                    While sqlReader.Read
                        starttime.Text = sqlReader(0).ToString
                        endtime.Text = sqlReader(1).ToString
                        auth.Text = sqlReader(2).ToString
                        title.Text = sqlReader(3).ToString
                    End While
                    sqlReader.Close()
                    con1.Close()

                    If Date.UtcNow >= CDate(starttime.Text).ToUniversalTime And Date.UtcNow <= CDate(endtime.Text).ToUniversalTime And auth.Text = "YES" Then 'if voting has started or not ended and account is activated

                        If userid.Text <> "" And votestatus.Text = "NO" Then 'voter exist and not voted
                            Session("votertname") = votername.Text
                            Session("voterid") = voterid.Text
                            Session("starttime") = starttime.Text
                            Session("endtime") = endtime.Text
                            Session("title") = title.Text
                            Session("votestatus") = votestatus.Text
                            Session("userid") = userid.Text
                            Response.Redirect("~/votepage.aspx")
                        ElseIf userid.Text = "" Then                           'voter does not exist
                            Lblvt.Text = "Incorrect Username or Password"
                        ElseIf userid.Text <> "" And votestatus.Text = "YES" Then 'voter exist but has voted
                            Lblvt.Text = "You have already voted"
                        End If

                    ElseIf Date.UtcNow <= CDate(starttime.Text).ToUniversalTime Then 'voting not started
                        Lblvt.Text = "Voting starts at " & CDate(starttime.Text).ToUniversalTime.ToString("D") & " " & CDate(starttime.Text).ToUniversalTime.ToLongTimeString.ToString
                    ElseIf Date.UtcNow >= CDate(endtime.Text).ToUniversalTime Then 'voting ended
                        Lblvt.Text = "Voting ended at " & CDate(endtime.Text).ToUniversalTime.ToString("D") & " " & CDate(endtime.Text).ToUniversalTime.ToLongTimeString.ToString
                    ElseIf auth.Text = "NO" Then 'account not activated
                        Lblvt.Text = "Sorry, your election account is not active, please see your administrator"
                    End If

                ElseIf lbxvt.Items.Count > 1 Then 'more than one account
                    Session("username") = tbxlogusername.Text
                    Session("password") = tbxlogpassword.Text
                    Response.Redirect("login_select.aspx")
                ElseIf lbxvt.Items.Count < 1 Then                           'voter does not exist
                    Lblvt.Text = "Incorrect Username or Password"
                End If
            End Using

        Catch ex As Exception

        End Try
    End Sub



    Protected Sub btnadmin_Click(sender As Object, e As EventArgs) Handles btncreatnew.Click
        Response.Redirect("~/signup.aspx")
    End Sub


    'Protected Sub btndownload_Click(sender As Object, e As EventArgs) Handles btndownload.Click
    '    Try
    '        lblrferror.Text = " " 'set error msg to null
    '        Lbldidplay.Text = "1"
    '        Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
    '            con.Open()
    '            Dim ss As String = "select indexno, level, department from tblvoters where userid=(select ID from signups where code=@code)"
    '            Dim myCommand As New SqlCommand(ss, con)
    '            myCommand.Parameters.AddWithValue("@code", tbxcode.Text)
    '            Dim da As New SqlDataAdapter(myCommand)
    '            Dim dt As New DataTable()
    '            da.Fill(dt)
    '            con.Close()
    '            If dt.Rows.Count > 0 Then
    '                Dim attachment As String = "attachment; filename=voterlist(votegh).xls"
    '                Response.ClearContent()
    '                Response.AddHeader("content-disposition", attachment)
    '                Response.ContentType = "application/vnd.ms-excel"
    '                Dim tab As String = ""
    '                For Each dc As DataColumn In dt.Columns
    '                    Response.Write(tab + dc.ColumnName)
    '                    tab = vbTab
    '                Next
    '                Response.Write(vbLf)
    '                Dim i As Integer
    '                For Each dr As DataRow In dt.Rows
    '                    tab = ""
    '                    For i = 0 To dt.Columns.Count - 1
    '                        Response.Write(tab & dr(i).ToString())
    '                        tab = vbTab
    '                    Next
    '                    Response.Write(vbLf)
    '                Next
    '                Response.[End]()
    '            ElseIf dt.Rows.Count = 0 Then
    '                lblrferror.Text = "No voterlist found for this organization"
    '            End If
    '        End Using

    '    Catch ex As Exception
    '        lblrferror.Text = "Incorrect code"
    '    End Try
    'End Sub

End Class