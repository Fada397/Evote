﻿Imports System.Data.SqlClient
Imports System.Configuration

Public Class m_login_select
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            MultiView1.ActiveViewIndex = 0
            tbxlogpassword.Text = Session("password")
            tbxlogusername.Text = Session("username")

            If tbxlogpassword.Text = "" Then 'if cookies disabled
                Response.Redirect("~/m.cookiesdisabled.aspx")
            End If
            getids()
        End If
    End Sub

    Protected Sub getids() 'get account userid
        Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
            Dim cmdvt As SqlCommand = New SqlCommand("voteid", con1)
            cmdvt.Connection = con1
            cmdvt.CommandText = "voteid"
            cmdvt.CommandType = CommandType.StoredProcedure
            cmdvt.Parameters.AddWithValue("@voterusername", tbxlogusername.Text)
            cmdvt.Parameters.AddWithValue("@voterpassword", tbxlogpassword.Text)
            con1.Open()
            Dim lbxvt As New ListBox
            Dim sqlReadervt As SqlDataReader = cmdvt.ExecuteReader()
            lbxvt.DataSource = sqlReadervt
            lbxvt.DataTextField = "userid"
            lbxvt.DataValueField = "ID"
            lbxvt.DataBind()
            sqlReadervt.Close()
            con1.Close()


            Do Until lbxvt.SelectedIndex = lbxvt.Items.Count - 1
                lbxvt.SelectedIndex += 1
                con1.Open()
                Dim cmd As SqlCommand = New SqlCommand("resultuseridname", con1)
                cmd.Connection = con1
                cmd.CommandText = "resultuseridname"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Parameters.AddWithValue("@userid", lbxvt.SelectedItem.ToString)
                Dim lbxvtslt As New ListBox
                lbxvtslt.DataSource = cmd.ExecuteReader
                lbxvtslt.DataTextField = "title"
                lbxvtslt.DataValueField = "ID"
                lbxvtslt.DataBind()
                con1.Close()
                lbxvtslt.SelectedIndex = 0

                lbxvotelog.Items.Add(lbxvtslt.SelectedItem.ToString)
                lbxvotelog.SelectedIndex = lbxvotelog.Items.Count - 1
                lbxvotelog.SelectedItem.Value = lbxvtslt.SelectedValue.ToString
            Loop
            lbxvotelog.SelectedIndex = -1
        End Using
    End Sub




    Protected Sub btnselectlog_Click(sender As Object, e As EventArgs) Handles btnselectlog.Click

        Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
            Dim dt As New DataTable()
            Dim myReader As SqlDataReader = Nothing
            Dim myReader1 As SqlDataReader = Nothing

            Dim starttime As New TextBox
            Dim endtime As New TextBox
            Dim auth As New TextBox
            Dim voterid As New TextBox
            Dim title As New TextBox
            Dim userid As New TextBox
            Dim votestatus As New TextBox
            Dim votername As New TextBox
            con1.Open()
            Dim cmdvt As SqlCommand = New SqlCommand("voteselect", con1)
            cmdvt.Connection = con1
            cmdvt.CommandText = "voteselect"
            cmdvt.CommandType = CommandType.StoredProcedure
            cmdvt.Parameters.AddWithValue("@voterusername", tbxlogusername.Text)
            cmdvt.Parameters.AddWithValue("@voterpassword", tbxlogpassword.Text)
            cmdvt.Parameters.AddWithValue("@userid", lbxvotelog.SelectedValue.ToString)
            Dim sqlReadervt As SqlDataReader = cmdvt.ExecuteReader()
            While sqlReadervt.Read
                votestatus.Text = sqlReadervt(1).ToString
                votername.Text = sqlReadervt(2).ToString
                voterid.Text = sqlReadervt(3).ToString
            End While
            sqlReadervt.Close()
            con1.Close()

            con1.Open()
            Dim cmd As SqlCommand = New SqlCommand("votelogin", con1)
            cmd.Connection = con1
            cmd.CommandText = "votelogin"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@userid", lbxvotelog.SelectedValue.ToString)
            Dim sqlReader As SqlDataReader = cmd.ExecuteReader()
            While sqlReader.Read
                starttime.Text = sqlReader(0).ToString
                endtime.Text = sqlReader(1).ToString
                auth.Text = sqlReader(2).ToString
                title.Text = sqlReader(3).ToString
            End While
            sqlReader.Close()
            con1.Close()

            If Date.UtcNow >= CDate(starttime.Text).ToUniversalTime And Date.UtcNow <= CDate(endtime.Text).ToUniversalTime And auth.Text = "YES" Then 'if voting has started or not ended and account is activated

                If votestatus.Text = "NO" Then 'voter exist and not voted
                    Session("votertname") = votername.Text
                    Session("voterid") = voterid.Text
                    Session("starttime") = starttime.Text
                    Session("endtime") = endtime.Text
                    Session("title") = title.Text
                    Session("votestatus") = votestatus.Text
                    Session("userid") = lbxvotelog.SelectedValue.ToString
                    Response.Redirect("~/m.vote.aspx")
                ElseIf votestatus.Text = "YES" Then 'voter exist but has voted
                    Lblvt.Text = "You have already voted"
                End If

            ElseIf Date.UtcNow <= CDate(starttime.Text).ToUniversalTime Then 'voting not started
                Lblvt.Text = "Voting starts at " & CDate(starttime.Text).ToUniversalTime.ToString("D") & " " & CDate(starttime.Text).ToUniversalTime.ToLongTimeString.ToString
            ElseIf Date.UtcNow >= CDate(endtime.Text).ToUniversalTime Then 'voting ended
                Lblvt.Text = "Voting ended at " & CDate(endtime.Text).ToUniversalTime.ToString("D") & " " & CDate(endtime.Text).ToUniversalTime.ToLongTimeString.ToString
            ElseIf auth.Text = "NO" Then 'account not activated
                Lblvt.Text = "Sorry, your election account is not active, please see your administrator"
            End If

        End Using
    End Sub
End Class