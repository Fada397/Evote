﻿Imports System.Net
Imports System.Data.SqlClient

Public Class manifesto
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim FilePath As String = Server.MapPath("manifesto/pdf1.pdf")
        Dim User As New WebClient()
        Dim FileBuffer As [Byte]() = User.DownloadData(FilePath)
        If FileBuffer IsNot Nothing Then
            Response.ContentType = "application/pdf"
            Response.AddHeader("content-length", FileBuffer.Length.ToString())
            Response.BinaryWrite(FileBuffer)

        End If
    End Sub

    Protected Sub btndownload_Click(sender As Object, e As EventArgs) Handles btndownload.Click
        'Dim strRequest As String = Request.QueryString("file") '-- if something was passed to the file querystring
        'If strRequest <> "" Then 'get absolute path of the file
        Dim path As String = Server.MapPath("manifesto/pdf1.pdf") 'get file object as FileInfo
        Dim file As System.IO.FileInfo = New System.IO.FileInfo(path) '-- if the file exists on the server
        If file.Exists Then 'set appropriate headers
            Response.Clear()
            Response.AddHeader("Content-Disposition", "attachment; filename=" & file.Name)
            Response.AddHeader("Content-Length", file.Length.ToString())
            Response.ContentType = "application/octet-stream"
            Response.WriteFile(file.FullName)
            Response.End() 'if file does not exist
        Else
            Response.Write("This file does not exist.")
        End If 'nothing in the URL as HTTP GET
        'Else
        '    Response.Write("Please provide a file to download.")
        'End If
    End Sub

    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)

            con1.Open()
            'find positions from position table
            Dim lbx As New ListBox
            Dim myReader1 As SqlDataReader = Nothing
            Dim query1 As String = "select name, phone from tblvoters where name <> @id"
            Dim myCommand1 As New SqlCommand(query1, con1)
            myCommand1.Parameters.AddWithValue("@id", "0101")
            lbx.DataSource = myCommand1.ExecuteReader()
            lbx.DataTextField = "name"
            lbx.DataValueField = "phone"
            lbx.DataBind()
            con1.Close()

            Dim tbxfrom As String = "Obana"
            Dim tbxto As String
            Dim i = 0
            ' Dim tbxmsg As String = "Comrade, Bernard Agyekum  BH 345 will like to thank u for the support so far. You have  demonstrated that u value capabilty to help move BH Unite forward. At this point what remains is for u to vote for me. I promise not to disappoint if voted as Vice President. Vote BH 325 Obana as Veep. Vote for a new face of BH Unite"
            lbx.SelectedIndex = 110
            Do Until lbx.SelectedIndex = 120
                tbxto = "233" & lbx.SelectedValue.ToString.Substring(lbx.SelectedValue.ToString.Length - 9, 9)


                ' Dim url As String = "https://api.smsgh.com/v3/messages/send?" + "From=" + tbxfrom + "&To=%2B" + tbxto + "" + "&Content=" + tbxmsg + "" + "&ClientId=vfwdjpjt" + "&ClientSecret=lysnrxhf" + "&RegisteredDelivery=true"
                Dim url As String = "https://api.smsgh.com/v3/messages/send?" + "From=" + tbxfrom + "&To=%2B" + tbxto + "" + "&Content=" + TextBox1.Text + "" + "&ClientId=irewgcsc" + "&ClientSecret=yznceuup" + "&RegisteredDelivery=true"


                Dim client As New Net.WebClient()
                Dim text As String = client.DownloadString(url)

                lbx.SelectedIndex += 1
                i += 1
            Loop
            MsgBox(i.ToString)
        End Using
    End Sub
End Class