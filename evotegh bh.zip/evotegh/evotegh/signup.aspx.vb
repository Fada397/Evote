﻿Imports System.Data.SqlClient
Imports System.Configuration
Imports System.Net

Public Class signup
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


        If Not IsPostBack Then
            MultiView1.ActiveViewIndex = 0
        End If
    End Sub

    Protected Sub btnsave_view1_Click(sender As Object, e As EventArgs) Handles btnsave_view1.Click
        Try

            tbxsignuporganization.Text = tbxsignuporganization.Text.Replace("`", "").Replace("~", "").Replace("!", "") _
         .Replace("@", "").Replace("#", "").Replace("$", "").Replace("%", "").Replace("^", "") _
         .Replace("&", "").Replace("*", "").Replace("(", "").Replace(")", "").Replace("_", "").Replace("-", "").Replace("+", "").Replace("=", "").Replace(";", "") _
         .Replace(":", "").Replace("/", "").Replace("'", "").Replace("?", "").Replace(".", "").Replace(">", "").Replace(",", "") _
         .Replace("<", "").Replace("[", "").Replace("{", "").Replace("}", "").Replace("]", "").Replace("\", "").Replace("|", "").Replace("}", "").Replace("""", "").Trim

            tbxtitle.Text = tbxtitle.Text.Replace("`", "").Replace("~", "").Replace("!", "") _
         .Replace("@", "").Replace("#", "").Replace("$", "").Replace("%", "").Replace("^", "") _
         .Replace("&", "").Replace("*", "").Replace("(", "").Replace(")", "").Replace("_", "").Replace("-", "").Replace("+", "").Replace("=", "").Replace(";", "") _
         .Replace(":", "").Replace("/", "").Replace("'", "").Replace("?", "").Replace(".", "").Replace(">", "").Replace(",", "") _
         .Replace("<", "").Replace("[", "").Replace("{", "").Replace("}", "").Replace("]", "").Replace("\", "").Replace("|", "").Replace("}", "").Replace("""", "").Trim

            tbxsignupusername.Text = tbxsignupusername.Text.Replace("`", "").Replace("~", "").Replace("!", "") _
         .Replace("@", "").Replace("#", "").Replace("$", "").Replace("%", "").Replace("^", "") _
         .Replace("&", "").Replace("*", "").Replace("(", "").Replace(")", "").Replace("_", "").Replace("-", "").Replace("+", "").Replace("=", "").Replace(";", "") _
         .Replace(":", "").Replace("/", "").Replace("'", "").Replace("?", "").Replace(".", "").Replace(">", "").Replace(",", "") _
         .Replace("<", "").Replace("[", "").Replace("{", "").Replace("}", "").Replace("]", "").Replace("\", "").Replace("|", "").Replace("}", "").Replace("""", "").Trim

            tbxsignuppassword.Text = tbxsignuppassword.Text.Replace("`", "").Replace("~", "").Replace("!", "") _
         .Replace("@", "").Replace("#", "").Replace("$", "").Replace("%", "").Replace("^", "") _
         .Replace("&", "").Replace("*", "").Replace("(", "").Replace(")", "").Replace("_", "").Replace("-", "").Replace("+", "").Replace("=", "").Replace(";", "") _
         .Replace(":", "").Replace("/", "").Replace("'", "").Replace("?", "").Replace(".", "").Replace(">", "").Replace(",", "") _
         .Replace("<", "").Replace("[", "").Replace("{", "").Replace("}", "").Replace("]", "").Replace("\", "").Replace("|", "").Replace("}", "").Replace("""", "").Trim

            tbxsignupconfirmpassword.Text = tbxsignupconfirmpassword.Text.Replace("`", "").Replace("~", "").Replace("!", "") _
                 .Replace("@", "").Replace("#", "").Replace("$", "").Replace("%", "").Replace("^", "") _
                 .Replace("&", "").Replace("*", "").Replace("(", "").Replace(")", "").Replace("_", "").Replace("-", "").Replace("+", "").Replace("=", "").Replace(";", "") _
                 .Replace(":", "").Replace("/", "").Replace("'", "").Replace("?", "").Replace(".", "").Replace(">", "").Replace(",", "") _
                 .Replace("<", "").Replace("[", "").Replace("{", "").Replace("}", "").Replace("]", "").Replace("\", "").Replace("|", "").Replace("}", "").Replace("""", "").Trim


            tbxadminam.Text = tbxadminam.Text.Replace("`", "").Replace("~", "").Replace("!", "") _
         .Replace("@", "").Replace("#", "").Replace("$", "").Replace("%", "").Replace("^", "") _
         .Replace("&", "").Replace("*", "").Replace("(", "").Replace(")", "").Replace("_", "").Replace("-", "").Replace("+", "").Replace("=", "").Replace(";", "") _
         .Replace(":", "").Replace("/", "").Replace("'", "").Replace("?", "").Replace(".", "").Replace(">", "").Replace(",", "") _
         .Replace("<", "").Replace("[", "").Replace("{", "").Replace("}", "").Replace("]", "").Replace("\", "").Replace("|", "").Replace("}", "").Replace("""", "").Trim



            tbxadminpone.Text = tbxadminpone.Text.Replace("`", "").Replace("~", "").Replace("!", "") _
         .Replace("@", "").Replace("#", "").Replace("$", "").Replace("%", "").Replace("^", "") _
         .Replace("&", "").Replace("*", "").Replace("(", "").Replace(")", "").Replace("_", "").Replace("-", "").Replace("+", "").Replace("=", "").Replace(";", "") _
         .Replace(":", "").Replace("/", "").Replace("'", "").Replace("?", "").Replace(".", "").Replace(">", "").Replace(",", "") _
         .Replace("<", "").Replace("[", "").Replace("{", "").Replace("}", "").Replace("]", "").Replace("\", "").Replace("|", "").Replace("}", "").Replace("""", "").Trim


            Dim strt As New TextBox
            Dim endt As New TextBox
            strt.Text = CDate(dbxstrtmnth.SelectedValue.ToString & "/" & dbxstrtdate.SelectedItem.ToString & "/" & dbxstrtyr.SelectedItem.ToString & " " & tbxstarttime.Text)
            endt.Text = CDate(dbxendmonth.SelectedValue.ToString & "/" & dbxenddate.SelectedItem.ToString & "/" & dbxendyr.SelectedItem.ToString & " " & tbxendtime.Text)
            If CDate(endt.Text) > CDate(strt.Text) Then  'end date should be greater than start date
                Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
                    Dim dt As New DataTable()
                    Dim myReader As SqlDataReader = Nothing
                    con1.Open()
                    'generate new code
                    Dim lbx As New ListBox
                    Dim query1 As String = "select code from signups  order by code "
                    Dim myCommand As New SqlCommand(query1, con1)
                    lbx.DataSource = myCommand.ExecuteReader
                    lbx.DataTextField = "code"
                    lbx.DataValueField = "code"
                    lbx.DataBind()
                    con1.Close()

                    lbx.SelectedIndex = lbx.Items.Count - 1 'select last code and increament
                    Dim ncode As String
                    If lbx.SelectedIndex >= 0 Then
                        ncode = CInt(lbx.SelectedItem.ToString + 1).ToString.PadLeft(4, "0"c)
                        '  ncode = ncode.ToString.PadLeft(4, "0"c)
                    Else
                        ncode = "0100"
                    End If

                    con1.Open()
                    'select statement to check lf username exist
                    Dim user1 As String = tbxsignupusername.Text
                    Dim present As String = ""
                    ' Dim query11 As String = "select * from signups where username='" + user1 & "' order by code "
                    Dim query11 As String = "select ID from signups where username COLLATE latin1_General_CS_AS=@user "
                    Dim myCommand1 As New SqlCommand(query11, con1)
                    myCommand1.Parameters.AddWithValue("@user", user1)
                    myReader = myCommand1.ExecuteReader()
                    While myReader.Read()
                        present = (myReader(0).ToString())
                    End While
                    con1.Close()

                    If present = "" Then
                        con1.Open()
                        Dim auth As String = "NO"

                        Dim strttim As String = (DateAdd(DateInterval.Hour, -5, CDate(strt.Text)))
                        Dim endtim As String = (DateAdd(DateInterval.Hour, -5, CDate(endt.Text)))

                        ' Dim query As String = "  insert into signups  values ('" + schol + "','" + dept + "','" + usern + "','" + pas + "','" + endvote + "','" + startvote + "','" + ncode + "','" + strtime + "','" + endtim + "','" + auth + "') "
                        Dim query As String = "  insert into signups  values (@schol, @title, @usern, @pas, @ncode, @strttime, @endtim , @auth , @lastupdate, @voterturnout, @adminnam, @email, @phone,@mailsent,@smssent) "
                        Dim cmd As New SqlCommand(query, con1)
                        cmd.Parameters.AddWithValue("@schol", tbxsignuporganization.Text)
                        cmd.Parameters.AddWithValue("@title", tbxtitle.Text)
                        cmd.Parameters.AddWithValue("@usern", tbxsignupusername.Text)
                        cmd.Parameters.AddWithValue("@pas", tbxsignuppassword.Text)
                        cmd.Parameters.AddWithValue("@ncode", ncode)
                        cmd.Parameters.AddWithValue("@strttime", strttim)
                        cmd.Parameters.AddWithValue("@endtim", endtim)
                        cmd.Parameters.AddWithValue("@auth", "NO")
                        cmd.Parameters.AddWithValue("@lastupdate", " ")
                        cmd.Parameters.AddWithValue("@voterturnout", 0)
                        cmd.Parameters.AddWithValue("@adminnam", tbxadminam.Text)
                        cmd.Parameters.AddWithValue("@email", tbxadminemail.Text)
                        cmd.Parameters.AddWithValue("@phone", tbxadminpone.Text)
                        cmd.Parameters.AddWithValue("@mailsent", "NO")
                        cmd.Parameters.AddWithValue("@smssent", "NO")
                        cmd.ExecuteNonQuery()
                        con1.Close()
                        MultiView1.ActiveViewIndex = 1
                        Dim content = "New Account created," + ControlChars.NewLine + " title:" + tbxtitle.Text + " phone: " + tbxadminpone.Text + " admin name: " + tbxadminam.Text + ""
                        'alert sms to evotegh
                        Dim url As String = "https://api.smsgh.com/v3/messages/send?" + "From=Evotegh&To=%2B233545894584" + "&Content=" + content + "" + "&ClientId=vfwdjpjt" + "&ClientSecret=lysnrxhf" + "&RegisteredDelivery=true"
                        Dim client As New WebClient()
                        Dim text As String = client.DownloadString(url)

                    Else
                        lblerror.Text = "ERROR: Username already exist"
                        tbxsignupusername.Focus()
                    End If
                End Using

            ElseIf CDate(endt.Text) <= CDate(strt.Text) Then
                lblerror1.Text = "ERROR, start time cannot be greater than end time"
            End If



        Catch ex As Exception

        End Try
    End Sub




    Protected Sub tbxsignupconfirmpassword_TextChanged(sender As Object, e As EventArgs) Handles tbxsignupconfirmpassword.TextChanged

    End Sub
End Class