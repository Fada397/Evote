﻿Imports System.Data.SqlClient
Imports System.Data.OleDb

Public Class spform
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub


    'Protected Sub Button3_Click(ByVal sender As Object, ByVal e As EventArgs) Handles hide.Click
    '    txt1.Text = Date.Now.ToString
    '    txt2.Text = Date.UtcNow.ToString
    '    Txt3.Text = DateDiff(DateInterval.Hour, Date.Now, Date.UtcNow)

    '    'Txt3.Text = CDate(Txt4.Text).ToString
    '    'Txt5.Text = CDate(Txt6.Text).ToUniversalTime.ToString
    'End Sub
End Class