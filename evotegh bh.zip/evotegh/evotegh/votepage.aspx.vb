﻿Imports System.Data.SqlClient
Imports System.Configuration

Public Class votepage
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            'pass all sessions from login page to textboxes
            tbxvotername.Text = Session("votertname")
            tbxvoterid.Text = Session("voterid")
            tbxstarttime.Text = Session("starttime")
            tbxendtime.Text = Session("endtime")
            tbxtitle.Text = Session("title")
            tbxuserid.Text = Session("userid")

           If tbxuserid.Text = "" Then 'if cookies disabled
                Response.Redirect("~/cookiesdisabled.aspx")
            End If

            lblwlcom.Text = "Welcome: " & tbxvotername.Text
            MultiView1.ActiveViewIndex = 0
            lbxselectdcand.Items.Add("")
            lbxselectdcand.SelectedIndex = lbxselectdcand.Items.Count - 1
        End If
        all()
    End Sub



    Protected Sub all()
        Try
            If Not IsPostBack Then
                Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
                    Dim dt As New DataTable()

                    'load positions
                    con1.Open()
                    Dim cmd As SqlCommand = New SqlCommand("loadpos", con1) 'Specify that the SqlCommand is a stored procedure
                    ' cmd.CommandType = System.Data.CommandType.StoredProcedure
                    cmd.Connection = con1
                    cmd.CommandText = "loadpos"
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Parameters.AddWithValue("@userid", tbxuserid.Text)
                    Dim sqlReader As SqlDataReader = cmd.ExecuteReader()
                    lbxpositions.DataSource = sqlReader
                    lbxpositions.DataTextField = "position"
                    lbxpositions.DataValueField = "Id"
                    lbxpositions.DataBind()
                    sqlReader.Close()
                    con1.Close()

                    lbxpositions.SelectedIndex = 0
                    tbxpos.Text = lbxpositions.SelectedItem.ToString.ToUpper
                    loadcandidates()

                    restitle.Text = tbxtitle.Text
                    tbxcfrmtitle.Text = tbxtitle.Text
                End Using

            End If


        Catch ex As Exception

        End Try

    End Sub

    Protected Sub loadcandidates()
        Try
            Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
                Dim dt As New DataTable()
                Dim myReader As SqlDataReader = Nothing

                'get the all candidates for the position 
                Dim lbx As New ListBox
                con1.Open()
                Dim cmd As SqlCommand = New SqlCommand("getcandid", con1) 'Specify that the SqlCommand is a stored procedure
                cmd.Connection = con1
                cmd.CommandText = "getcandid"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Parameters.AddWithValue("@posid", lbxpositions.SelectedValue.ToString)
                Dim sqlReader1 As SqlDataReader = cmd.ExecuteReader()
                lbx.DataSource = sqlReader1
                lbx.DataTextField = "Id"
                lbx.DataValueField = "Id"
                lbx.DataBind()
                sqlReader1.Close()
                con1.Close()

                'check if position has candidates 
                If lbx.Items.Count <> 0 Then
                    lbx.SelectedIndex = -1
                    Do Until lbx.SelectedIndex = lbx.Items.Count - 1
                        con1.Open()
                        lbx.SelectedIndex += 1

                        Dim cmd1 As SqlCommand = New SqlCommand("loadcand", con1) 'Specify that the SqlCommand is a stored procedure
                        cmd1.Connection = con1
                        cmd1.CommandText = "loadcand"
                        cmd1.CommandType = CommandType.StoredProcedure
                        cmd1.Parameters.AddWithValue("@candid", lbx.SelectedItem.ToString)
                        Dim myReader1 As SqlDataReader = cmd1.ExecuteReader()
                        While myReader1.Read()
                            If (myReader1(0).ToString()) <> "" Then
                                ' tbxlast.Text = (myReader1(1).ToString())
                                Dim tbx As New TextBox
                                tbx.Text = (myReader1(0).ToString())
                                tbx.ForeColor = Drawing.Color.Black
                                tbx.ReadOnly = True
                                tbx.BackColor = Drawing.Color.White
                                tbx.BorderStyle = BorderStyle.None
                                ' tbx.Style.Add("margin-left", "20px")
                                tbx.Style.Add("Font-Names", "Times New Roman")
                                tbx.Style.Add("width", "270pt")
                                tbx.Style.Add("Font-size", "16px")
                                tbx.Style.Add("text-align", "center")

                                tbx.Enabled = False
                                tbx.Font.Bold = True
                                Dim pane As New Panel
                                Dim imag As New Image

                                ' pane.BorderWidth = 10
                                imag.Width = 80
                                pane.BorderColor = Drawing.Color.White
                                candpanel.Controls.Add(pane)
                                imag.ImageAlign = ImageAlign.Middle
                                imag.BorderWidth = 1
                                imag.Style.Add("width", "80px")
                                imag.Style.Add("height", "80px")

                                radio1.Items.Add(New ListItem("", (myReader1(2).ToString())))

                                radio1.CellPadding = 22
                                radio1.CellSpacing = 22

                                pane.Controls.Add(tbx)
                                pane.Controls.Add(imag)


                                'If icreaseid Mod 2 = 1 Then
                                If lbx.SelectedIndex.ToString Mod 2 = 1 Then
                                    pane.Style.Add("background-color", "#EEEEEE")
                                    tbx.Style.Add("background-color", "#EEEEEE")
                                Else
                                    pane.Style.Add("background-color", "#E0E0E0")
                                    tbx.Style.Add("background-color", "#E0E0E0")
                                End If

                                imag.ImageUrl = "~/databasepics/" & (myReader1(1).ToString())
                                Session("img") = "~/databasepics/" & (myReader1(1).ToString())

                            End If
                        End While
                        myReader1.Close()
                        con1.Close()
                    Loop

                Else

                    If tbxskip.Text = "F" Then
                        btnforwrd_Click(btnforwrd, Nothing)
                    ElseIf tbxskip.Text = "B" Then
                        btnback_Click(btnback, Nothing)
                    ElseIf tbxskip.Text = "C" Then
                        MultiView1.ActiveViewIndex = 0
                        btnback_Click(btnback, Nothing)
                    End If

                End If
            End Using

        Catch ex As Exception

        End Try
    End Sub




    Protected Sub emptydata()
        Dim tbxpos1 As New TextBox
        tbxpos1.ForeColor = Drawing.Color.Black
        tbxpos1.ReadOnly = True
        tbxpos1.BackColor = Drawing.Color.White
        tbxpos1.BorderStyle = BorderStyle.None
        tbxpos1.Enabled = False
        tbxpos1.Text = lbxpositions.SelectedItem.ToString.ToUpper
        tbxpos1.Style.Add("Font-Names", "Times New Roman")
        tbxpos1.Style.Add("text-align", "center")
        tbxpos1.Style.Add("width", "170pt")
        tbxpos1.Font.Bold = True


        Dim tbxnam1 As New TextBox
        tbxnam1.Text = "Null"
        tbxnam1.ForeColor = Drawing.Color.Black
        tbxnam1.ReadOnly = True
        tbxnam1.BackColor = Drawing.Color.White
        tbxnam1.BorderStyle = BorderStyle.None
        tbxnam1.Enabled = False
        tbxnam1.Style.Add("Font-Names", "Times New Roman")
        tbxnam1.Style.Add("width", "285pt")
        tbxnam1.Font.Bold = True
        tbxnam1.Style.Add("text-align", "center")


        Dim pane1 As New Panel
        Dim imag1 As New Image
        ' pane1.BorderWidth = 10
        pane1.BorderColor = Drawing.Color.White
        pane1.BorderStyle = BorderStyle.Solid
        pane1.BorderWidth = 1



        imag1.Width = 80
        imag1.Height = 80
        imag1.ImageAlign = ImageAlign.Middle
        imag1.BorderWidth = 1
        imag1.ImageUrl = ("~/images/emptyvote.jpg")
        imag1.Style.Add("width", "80px")
        confirmpanel.Controls.Add(pane1)
        pane1.Controls.Add(tbxpos1)
        pane1.Controls.Add(tbxnam1)
        pane1.Controls.Add(imag1)




        pane1.Style.Add("background-color", "#EEEEEE")
        tbxnam1.Style.Add("background-color", "#EEEEEE")
        tbxpos1.Style.Add("background-color", "#EEEEEE")


    End Sub


    Protected Sub loadconfirmvote()
        Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
            Dim dt1 As New DataTable()
            Dim myReader2 As SqlDataReader = Nothing

            lbxselectdcand.SelectedIndex = -1
            lbxpositions.SelectedIndex = -1

            Do Until lbxpositions.SelectedIndex = lbxpositions.Items.Count - 1
                con1.Open()
                lbxpositions.SelectedIndex += 1
                lbxselectdcand.SelectedIndex += 1
                If lbxselectdcand.SelectedItem.ToString = "" Then
                    emptydata()
                End If

                Dim cmd As SqlCommand = New SqlCommand("loadcand", con1) 'Specify that the SqlCommand is a stored procedure
                cmd.Connection = con1
                cmd.CommandText = "loadcand"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Parameters.AddWithValue("@candid", lbxselectdcand.SelectedItem.ToString)
                myReader2 = cmd.ExecuteReader()
                While myReader2.Read()
                    Dim tbxpos As New TextBox
                    tbxpos.ForeColor = Drawing.Color.Black
                    tbxpos.ReadOnly = True
                    tbxpos.BackColor = Drawing.Color.White
                    tbxpos.BorderStyle = BorderStyle.None
                    tbxpos.Font.Bold = True
                    tbxpos.Enabled = False
                    tbxpos.Text = lbxpositions.SelectedItem.ToString.ToUpper
                    tbxpos.Style.Add("text-align", "center")
                    tbxpos.Style.Add("width", "170pt")

                    Dim tbxnam As New TextBox
                    tbxnam.Text = (myReader2(0).ToString())
                    tbxnam.ForeColor = Drawing.Color.Black
                    tbxnam.ReadOnly = True
                    tbxnam.BackColor = Drawing.Color.White
                    tbxnam.BorderStyle = BorderStyle.None
                    tbxnam.Enabled = False
                    tbxnam.Font.Bold = True
                    tbxnam.Style.Add("text-align", "center")
                    tbxnam.Style.Add("width", "285pt")

                    Dim pane As New Panel
                    Dim imag As New Image
                    'pane.BorderWidth = 10
                    pane.BorderColor = Drawing.Color.White

                    confirmpanel.Controls.Add(pane)
                    imag.Width = 80
                    imag.Height = 80
                    imag.ImageAlign = ImageAlign.Middle
                    imag.Style.Add("width", "80px")
                    imag.BorderWidth = 1
                    pane.Controls.Add(tbxpos)
                    pane.Controls.Add(tbxnam)
                    pane.Controls.Add(imag)


                    If CDec(lbxpositions.SelectedIndex) Mod 2 = 1 Then
                        pane.Style.Add("background-color", "#EEEEEE")
                        tbxnam.Style.Add("background-color", "#EEEEEE")
                        tbxpos.Style.Add("background-color", "#EEEEEE")
                    Else
                        pane.Style.Add("background-color", "#E0E0E0")
                        tbxnam.Style.Add("background-color", "#E0E0E0")
                        tbxpos.Style.Add("background-color", "#E0E0E0")
                    End If

                    imag.ImageUrl = "~/databasepics/" & (myReader2(1).ToString())
                    Session("img") = "~/databasepics/" & (myReader2(1).ToString())
                End While
                myReader2.Close()
                con1.Close()
            Loop
        End Using
    End Sub



    Protected Sub btnforwrd_Click(sender As Object, e As System.Web.UI.ImageClickEventArgs) Handles btnforwrd.Click

        Try
            If lbxpositions.SelectedIndex = 0 Then
                btnback.Enabled = True
            End If

            If lbxpositions.SelectedIndex < lbxpositions.Items.Count - 1 Then
                lbxselectdcand.Items.RemoveAt(lbxselectdcand.SelectedIndex.ToString)
                lbxselectdcand.Items.Add(radio1.SelectedValue.ToString)
                lbxselectdcand.Items.Add("")
                lbxselectdcand.SelectedIndex = lbxselectdcand.Items.Count - 1

                radio1.Items.Clear()
                lbxpositions.SelectedIndex += 1

                tbxskip.Text = "F"
                loadcandidates()
            ElseIf lbxpositions.SelectedIndex = lbxpositions.Items.Count - 1 Then
                lbxselectdcand.Items.RemoveAt(lbxselectdcand.SelectedIndex.ToString)
                lbxselectdcand.Items.Add(radio1.SelectedValue.ToString)
                MultiView1.ActiveViewIndex = 1
                loadconfirmvote()
            End If
            tbxpos.Text = lbxpositions.SelectedItem.ToString.ToUpper

            'select 
            'If lbxselectdcand.SelectedItem.ToString <> "" Then
            '    radio1.SelectedValue = lbxselectdcand.SelectedItem.ToString
            'End If

        Catch ex As Exception
        End Try
    End Sub



    Protected Sub lbxpositions_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lbxpositions.SelectedIndexChanged
        tbxpos.Text = lbxpositions.SelectedItem.ToString.ToUpper
    End Sub

    Protected Sub btncfrmback_Click(sender As Object, e As System.Web.UI.ImageClickEventArgs) Handles btncfrmback.Click

        tbxskip.Text = "C"
        MultiView1.ActiveViewIndex = 0
        radio1.Items.Clear()
        btnforwrd.Enabled = True
        loadcandidates()
        If lbxselectdcand.SelectedItem.ToString <> "" Then
            radio1.SelectedValue = lbxselectdcand.SelectedItem.ToString
        End If
    End Sub

    Protected Sub btncfrm_Click(sender As Object, e As System.Web.UI.ImageClickEventArgs) Handles btncfrm.Click
        Try

       
        Using con1 As New SqlConnection(ConfigurationManager.ConnectionStrings("connection").ConnectionString)
            Dim dt1 As New DataTable()
            Dim myReader2 As SqlDataReader = Nothing

            lbxselectdcand.SelectedIndex = -1
            lbxpositions.SelectedIndex = -1

            con1.Open()      'check if candidate votestatus
            Dim cmdcv As SqlCommand = New SqlCommand("cfrmvotestatus", con1) 'Specify that the SqlCommand is a stored procedure
            cmdcv.Connection = con1
            cmdcv.CommandText = "cfrmvotestatus"
            cmdcv.CommandType = CommandType.StoredProcedure
            cmdcv.Parameters.AddWithValue("@voterid", tbxvoterid.Text)

            cmdcv.Parameters.Add("@votestatus", SqlDbType.NVarChar)
            cmdcv.Parameters("@votestatus").Direction = ParameterDirection.Output
            cmdcv.Parameters("@votestatus").Size = 10

            Dim sqlReader As SqlDataReader = cmdcv.ExecuteReader()
            sqlReader.Close()
            tbxvotestatus.Text = Convert.ToString(cmdcv.Parameters("@votestatus").Value)
            con1.Close()

            If Date.UtcNow >= CDate(tbxstarttime.Text).ToUniversalTime And Date.UtcNow <= CDate(tbxendtime.Text).ToUniversalTime Then 'check if voting still in progress
                If tbxvotestatus.Text = "NO" Then
                    Do Until lbxpositions.SelectedIndex = lbxpositions.Items.Count - 1
                        lbxpositions.SelectedIndex += 1
                        lbxselectdcand.SelectedIndex += 1
                        'retrieve candiate votes
                        con1.Open()      'update candidate votes
                        Dim cmd As SqlCommand = New SqlCommand("vote", con1) 'Specify that the SqlCommand is a stored procedure
                        cmd.Connection = con1
                        cmd.CommandText = "vote"
                        cmd.CommandType = CommandType.StoredProcedure
                        cmd.Parameters.AddWithValue("@candid", lbxselectdcand.SelectedItem.ToString)
                        cmd.ExecuteNonQuery()
                        con1.Close()
                    Loop

                    con1.Open() 'set voter votesstatus to YES
                    Dim vot As String = "YES"
                    Dim cmdsetvst As SqlCommand = New SqlCommand("setvstatus", con1) 'Specify that the SqlCommand is a stored procedure
                    cmdsetvst.Connection = con1
                    cmdsetvst.CommandText = "setvstatus"
                    cmdsetvst.CommandType = CommandType.StoredProcedure
                    cmdsetvst.Parameters.AddWithValue("@voterid", tbxvoterid.Text)
                    cmdsetvst.Parameters.AddWithValue("@votestatus", vot)
                    cmdsetvst.ExecuteNonQuery()
                    con1.Close()


                    lblwlcom.Visible = False
                    MultiView1.ActiveViewIndex = 2
                    lblvotemsg.Style.Add("color", "#008000")

                ElseIf tbxvotestatus.Text = "YES" Then 'already voted
                    lblwlcom.Visible = False
                    MultiView1.ActiveViewIndex = 2
                    lblvotemsg.ForeColor = Drawing.Color.Red
                    lblvotemsg.Text = "Vote Unsuccessful, you have already voted."

                End If

            ElseIf Date.UtcNow >= CDate(tbxendtime.Text).ToUniversalTime Then 'voting ended

                lblwlcom.Visible = False
                MultiView1.ActiveViewIndex = 2
                lblvotemsg.ForeColor = Drawing.Color.Red
                lblvotemsg.Text = "Vote Unsuccessful, Voting ended at " & CDate(tbxendtime.Text).ToUniversalTime.ToString("D") & " " & CDate(tbxendtime.Text).ToUniversalTime.ToLongTimeString.ToString

            End If
            End Using

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Session.Abandon()
        Response.Redirect("~/default.aspx")

    End Sub

    Protected Sub btnback_Click(sender As Object, e As System.Web.UI.ImageClickEventArgs) Handles btnback.Click

        Try
            radio1.Items.Clear()
            If lbxpositions.SelectedIndex > 0 Then
                lbxpositions.SelectedIndex -= 1
                tbxskip.Text = "B"
                loadcandidates()
            End If
            If lbxpositions.SelectedIndex = 0 Then
                btnback.Enabled = False
            End If


            lbxselectdcand.Items.RemoveAt(lbxselectdcand.SelectedIndex.ToString)
            lbxselectdcand.SelectedIndex = lbxselectdcand.Items.Count - 1

            'select the chosed candidate 
            If lbxselectdcand.SelectedItem.ToString <> "" Then
                radio1.SelectedValue = lbxselectdcand.SelectedItem.ToString
            End If
            tbxpos.Text = lbxpositions.SelectedItem.ToString.ToUpper
        Catch ex As Exception
        End Try
    End Sub
End Class